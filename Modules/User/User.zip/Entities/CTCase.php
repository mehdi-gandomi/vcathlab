<?php

namespace Modules\User\Entities;

use Illuminate\Database\Eloquent\Model;

class CTCase extends Model
{
    protected $fillable = [];
    protected $table = 'ct_cases';
}
