<!DOCTYPE html>
<html>

<head>
    <title>AOBP Result</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <style>
        .table-header{
            background: #fde9d9
        }
        @media print {
        body { color-adjust: exact; }
        }

    </style>
</head>

<body>
    <div class="container">
        <h1 class="text-center">AOBP Result</h1>
        <div class="result-wrap ">
            <div class="patient-table">
                <table class="table table-bordered">
                    <thead>
                        <tr class="table-header">
                            <th colspan="5">Patient</th>

                        </tr>
                    </thead>
                    <tbody>
                        <tr class="border-bottom-0">
                            <td colspan="2" class="border-end-0">
                                Name: Mehdi
                            </td>
                            <td colspan="2" class="border-start-0 border-end-0">
                                Code: 123
                            </td>
                            <td colspan="1" class="border-start-0">

                            </td>
                        </tr>
                        <tr class="border-top-0">
                            <td colspan="2" class="border-end-0">
                                Age: 24
                            </td>
                            <td colspan="2" class="border-start-0 border-end-0">
                                Gender: Male
                            </td>
                            <td colspan="1" class="border-start-0 ">

                            </td>
                        </tr>
                    </tbody>

                </table>

            </div>
            <div class="aobp-table">
                <table class="table table-bordered">
                    <thead>
                        <tr class="table-header">
                            <th colspan="5"> AOBP Statistics</th>

                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="border-end-0">

                            </td>
                            <td class="border-end-0 border-start-0">
                                Mean
                            </td>
                            <td class="border-end-0 border-start-0">
                                Std. Dev
                            </td>
                            <td class="border-end-0 border-start-0">
                                Max
                            </td>
                            <td class=" border-start-0">
                                Min
                            </td>
                        </tr>
                        <tr>
                            <td class="border-end-0">
                                SYS (mmHg)
                            </td>
                            <td class="border-end-0 border-start-0">
                                {Ave(SYS}
                            </td>
                            <td class="border-end-0 border-start-0">
                                {STD(SYS}                            </td>
                            <td class="border-end-0 border-start-0">
                                {MAX(STD}
                            </td>
                            <td class=" border-start-0">
                                {MIN(STD}
                            </td>
                        </tr>
                        <tr>
                            <td class="border-end-0">
                                DIA (mmHg)
                            </td>
                            <td class="border-end-0 border-start-0">
                                {Ave(DIA}
                            </td>
                            <td class="border-end-0 border-start-0">
                                {STD(DIA}
                            <td class="border-end-0 border-start-0">
                                {MAX(DIA}
                            </td>
                            <td class=" border-start-0">
                                {MIN(DIA}
                            </td>
                        </tr>
                        <tr>
                            <td class="border-end-0">
                                HR (bpm)
                            </td>
                            <td class="border-end-0 border-start-0">
                                {Ave(HR}
                            </td>
                            <td class="border-end-0 border-start-0">
                                {STD(HR}
                            <td class="border-end-0 border-start-0">
                                {MAX(HR}
                            </td>
                            <td class=" border-start-0">
                                {MIN(HR}
                            </td>
                        </tr>
                        <tr>
                            <td class="border-end-0">
                                MAP (mmHg)
                            </td>
                            <td class="border-end-0 border-start-0">
                                {Ave(MAP}
                            </td>
                            <td class="border-end-0 border-start-0">
                                {STD(MAP}
                            <td class="border-end-0 border-start-0">
                                {MAX(MAP}
                            </td>
                            <td class=" border-start-0">
                                {MIN(MAP}
                            </td>
                        </tr>
                        <tr>
                            <td class="border-end-0">
                                PP (mmHg)
                            </td>
                            <td class="border-end-0 border-start-0">
                                {Ave(PP}
                            </td>
                            <td class="border-end-0 border-start-0">
                                {STD(PP}
                            <td class="border-end-0 border-start-0">
                                {MAX(PP}
                            </td>
                            <td class=" border-start-0">
                                {MIN(PP}
                            </td>
                        </tr>
                        <tr>
                            <td class="border-end-0">
                                CO (l/min)
                            </td>
                            <td class="border-end-0 border-start-0">
                                {Ave(CO}
                            </td>
                            <td class="border-end-0 border-start-0">
                                {STD(CO}
                            <td class="border-end-0 border-start-0">
                                {MAX(CO}
                            </td>
                            <td class=" border-start-0">
                                {MIN(CO}
                            </td>
                        </tr>
                        <tr>
                            <td class="border-end-0">
                                CI (l/min/m2)
                            </td>
                            <td class="border-end-0 border-start-0">
                                {Ave(CI}
                            </td>
                            <td class="border-end-0 border-start-0">
                                {STD(CI}
                            <td class="border-end-0 border-start-0">
                                {MAX(CI}
                            </td>
                            <td class=" border-start-0">
                                {MIN(CI}
                            </td>
                        </tr>
                        <tr>
                            <td class="border-end-0" colspan="5">
                                <canvas  id="line-chart"></canvas>
                            </td>

                        </tr>
                    </tbody>

                </table>

            </div>
            <div class="result-table">
                <table class="table table-bordered">
                    <thead>
                        <tr class="table-header">
                            <th colspan="5">Result</th>

                        </tr>
                    </thead>
                    <tbody>
                        <tr class="border-bottom-0">
                            <td colspan="5" class="border-end-0">
                                <ul>
                                    <li>
                                        45% of SBP values were > 130 mmHg and 41% of DBP values were > 85 mmHg.
                                    </li>
                                    <li>
                                        55% of SBP and 59% of DBP readings were normal value (SBP < 130 mmHg and DBP < 85 mmHg).
                                    </li>
                                    <li>
                                        Mean home SBP/DBP = 127 / 84 mmHg (Max SBP = 160 mmHg and Max DBP = 99 mmHg).
                                    </li>
                                    <li>
                                        Classification of the patient was white-coat hypertension. (Office SBP/DBP = 165 / 85 mmHg)
                                    </li>
                                    <li>
                                        Recommended lifestyle changes and drug treatment (if CVD risk > 7.5% and SBP > 135 mmHg).
                                    </li>
                                </ul>


                            </td>

                        </tr>
                    </tbody>

                </table>
            </div>
        </div>

    </div>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        new Chart(document.getElementById("line-chart"), {
            type: 'line',
            data: {
                labels: [1500, 1600, 1700, 1750, 1800, 1850,
                    1900, 1950, 1999, 2050
                ],
                datasets: [{
                        data: [186, 205, 1321, 1516, 2107,
                            2191, 3133, 3221, 4783, 5478
                        ],
                        label: "America",
                        borderColor: "#3cba9f",
                        fill: false
                    },
                    {
                        data: [1282, 1350, 2411, 2502, 2635,
                            2809, 3947, 4402, 3700, 5267
                        ],
                        label: "Europe",
                        borderColor: "#e43202",
                        fill: false
                    }
                ]
            },
            options: {
                title: {
                    display: true,
                    text: 'Chart JS Multiple Lines Example'
                }
            }
        });
    </script>
</body>

</html>
