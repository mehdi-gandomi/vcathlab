(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[7],{

/***/ "../AccessLevel/Resources/js/components/Tree.vue":
/*!*******************************************************!*\
  !*** ../AccessLevel/Resources/js/components/Tree.vue ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Tree_vue_vue_type_template_id_14dce278___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Tree.vue?vue&type=template&id=14dce278& */ "../AccessLevel/Resources/js/components/Tree.vue?vue&type=template&id=14dce278&");
/* harmony import */ var _Tree_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Tree.vue?vue&type=script&lang=js& */ "../AccessLevel/Resources/js/components/Tree.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _Tree_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Tree.vue?vue&type=style&index=0&lang=scss& */ "../AccessLevel/Resources/js/components/Tree.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _Panel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../Panel/node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_Panel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Tree_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Tree_vue_vue_type_template_id_14dce278___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Tree_vue_vue_type_template_id_14dce278___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "AccessLevel/Resources/js/components/Tree.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "../AccessLevel/Resources/js/components/Tree.vue?vue&type=script&lang=js&":
/*!********************************************************************************!*\
  !*** ../AccessLevel/Resources/js/components/Tree.vue?vue&type=script&lang=js& ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Panel_node_modules_babel_loader_lib_index_js_ref_4_0_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Tree_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../Panel/node_modules/babel-loader/lib??ref--4-0!../../../../Panel/node_modules/vue-loader/lib??vue-loader-options!./Tree.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../AccessLevel/Resources/js/components/Tree.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_Panel_node_modules_babel_loader_lib_index_js_ref_4_0_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Tree_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "../AccessLevel/Resources/js/components/Tree.vue?vue&type=style&index=0&lang=scss&":
/*!*****************************************************************************************!*\
  !*** ../AccessLevel/Resources/js/components/Tree.vue?vue&type=style&index=0&lang=scss& ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Panel_node_modules_style_loader_index_js_Panel_node_modules_css_loader_index_js_Panel_node_modules_vue_loader_lib_loaders_stylePostLoader_js_Panel_node_modules_postcss_loader_src_index_js_ref_6_2_Panel_node_modules_sass_loader_dist_cjs_js_ref_6_3_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Tree_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../Panel/node_modules/style-loader!../../../../Panel/node_modules/css-loader!../../../../Panel/node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../Panel/node_modules/postcss-loader/src??ref--6-2!../../../../Panel/node_modules/sass-loader/dist/cjs.js??ref--6-3!../../../../Panel/node_modules/vue-loader/lib??vue-loader-options!./Tree.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!../AccessLevel/Resources/js/components/Tree.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _Panel_node_modules_style_loader_index_js_Panel_node_modules_css_loader_index_js_Panel_node_modules_vue_loader_lib_loaders_stylePostLoader_js_Panel_node_modules_postcss_loader_src_index_js_ref_6_2_Panel_node_modules_sass_loader_dist_cjs_js_ref_6_3_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Tree_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_Panel_node_modules_style_loader_index_js_Panel_node_modules_css_loader_index_js_Panel_node_modules_vue_loader_lib_loaders_stylePostLoader_js_Panel_node_modules_postcss_loader_src_index_js_ref_6_2_Panel_node_modules_sass_loader_dist_cjs_js_ref_6_3_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Tree_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _Panel_node_modules_style_loader_index_js_Panel_node_modules_css_loader_index_js_Panel_node_modules_vue_loader_lib_loaders_stylePostLoader_js_Panel_node_modules_postcss_loader_src_index_js_ref_6_2_Panel_node_modules_sass_loader_dist_cjs_js_ref_6_3_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Tree_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _Panel_node_modules_style_loader_index_js_Panel_node_modules_css_loader_index_js_Panel_node_modules_vue_loader_lib_loaders_stylePostLoader_js_Panel_node_modules_postcss_loader_src_index_js_ref_6_2_Panel_node_modules_sass_loader_dist_cjs_js_ref_6_3_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Tree_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "../AccessLevel/Resources/js/components/Tree.vue?vue&type=template&id=14dce278&":
/*!**************************************************************************************!*\
  !*** ../AccessLevel/Resources/js/components/Tree.vue?vue&type=template&id=14dce278& ***!
  \**************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Panel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Tree_vue_vue_type_template_id_14dce278___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../Panel/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../Panel/node_modules/vue-loader/lib??vue-loader-options!./Tree.vue?vue&type=template&id=14dce278& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../AccessLevel/Resources/js/components/Tree.vue?vue&type=template&id=14dce278&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _Panel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Tree_vue_vue_type_template_id_14dce278___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _Panel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Tree_vue_vue_type_template_id_14dce278___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../AccessLevel/Resources/js/components/Tree.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!../AccessLevel/Resources/js/components/Tree.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @node_modules/vuex */ "./node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var _node_modules_vue_deepset__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @node_modules/vue-deepset */ "./node_modules/vue-deepset/index.js");
/* harmony import */ var _node_modules_vue_deepset__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_deepset__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mixins_trans__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/mixins/trans */ "./Resources/js/src/mixins/trans.js");
/* harmony import */ var _mixins_trans__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mixins_trans__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_riophae_vue_treeselect__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @node_modules/@riophae/vue-treeselect */ "./node_modules/@riophae/vue-treeselect/dist/vue-treeselect.cjs.js");
/* harmony import */ var _node_modules_riophae_vue_treeselect__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_riophae_vue_treeselect__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_riophae_vue_treeselect_dist_vue_treeselect_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @node_modules/@riophae/vue-treeselect/dist/vue-treeselect.css */ "./node_modules/@riophae/vue-treeselect/dist/vue-treeselect.css");
/* harmony import */ var _node_modules_riophae_vue_treeselect_dist_vue_treeselect_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_riophae_vue_treeselect_dist_vue_treeselect_css__WEBPACK_IMPORTED_MODULE_5__);


function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
var Vue = window.Vue;





Vue.use(_node_modules_vuex__WEBPACK_IMPORTED_MODULE_1__["default"]);
Vue.use(_node_modules_vue_deepset__WEBPACK_IMPORTED_MODULE_2__);
Vue.component('treeselect', _node_modules_riophae_vue_treeselect__WEBPACK_IMPORTED_MODULE_4___default.a);
var STATE_CHECKED = 2;
var STATE_UNCHECKED = 0;
var store = new _node_modules_vuex__WEBPACK_IMPORTED_MODULE_1__["default"].Store({
  state: {
    treeValue: [],
    checkData: {}
  },
  mutations: _node_modules_vue_deepset__WEBPACK_IMPORTED_MODULE_2__["extendMutation"]({
    updateValue: function updateValue(state, value) {
      state.treeValue = value;
    },
    updateChecked: function updateChecked(state, value) {
      var _i;

      for (_i in state.checkData) {
        state.checkData[_i] = [];
        delete state.checkData[_i];
      }

      for (_i in value) {
        state.checkData[_i] = value[_i];
      }
    }
  })
});
var private_scope = {
  prevSelection: 0,
  findParent: function findParent(checkBox) {
    while (checkBox.$parent) {
      if (~checkBox.$parent.$el.className.indexOf('tree-component')) return checkBox.$parent;
      checkBox = checkBox.$parent;
    }

    return null;
  },
  uniqueArray: function uniqueArray(inArray) {
    return Array.from(new Set(inArray));
  },
  boolVar: function boolVar(val) {
    return !!+val;
  },
  boolMap: function boolMap(val) {
    if (val.constructor == Array) return val.map(function (v) {
      return private_scope["bool".concat(_typeof(v) != 'object' ? 'Var' : 'Map')](v);
    });
    var result = {};
    return Object.entries(val).forEach(function (v) {
      return result[v[0]] = private_scope["bool".concat(_typeof(v[1]) != 'object' ? 'Var' : 'Map')](v[1]);
    }), result;
  },
  abilitiesToPermissions: function abilitiesToPermissions(abilities) {
    return private_scope.boolMap(_objectSpread({
      0: [0, 0, 0, 0, 0, 0]
    }, abilities));
  },
  // Main Part of job done in Laravel
  components: {},
  // save $refs to checkBoxes
  changing: {},
  // ids of elements in changing
  events: {},
  origError: function origError() {}
};
var __ = _mixins_trans__WEBPACK_IMPORTED_MODULE_3___default.a.methods.__;
/* harmony default export */ __webpack_exports__["default"] = ({
  store: store,
  data: function data() {
    return {
      selectedId: 0,
      tree: [],
      forest: {},
      checkboxes: [[__('Index'), 'primary'], [__('Create'), 'success'], [__('Update'), 'warning'], [__('Delete'), 'danger'], [__('Export'), 'dark'], [__('Upload'), '#F80']] // checked: {}

    };
  },
  props: {
    permissions: {
      type: Object,
      "default": function _default() {
        return {};
      }
    }
  },
  watch: {
    permissions: function permissions(newPermissions) {
      var _this = this;

      this.clearAll(); // if(newPermissions.constructor == Object)

      Object.entries(newPermissions).forEach(function (permission) {
        var node_id = permission[0];

        _this.removeValue(node_id);

        _this.$vuexSet("checkData.".concat(node_id), private_scope.boolMap(permission[1]));

        _this.appendValue(node_id);
      });
    }
  },
  computed: _objectSpread(_objectSpread({}, Object(_node_modules_vuex__WEBPACK_IMPORTED_MODULE_1__["mapState"])(['treeValue'])), {}, {
    checkData: function checkData() {
      return this.$deepModel('checkData');
    },
    _selectedId: function _selectedId() {
      var selectedId = this.selectedId;
      if (!this.checkData[selectedId]) this.$vuexSet("checkData.".concat(selectedId), private_scope.boolMap([0, 0, 0, 0, 0, 0]));
      return selectedId;
    },
    treeHeight: function treeHeight() {
      return window.innerHeight;
    },
    checkBoxTitle: function checkBoxTitle() {
      return "<i class=\"".concat(this.findBranchInTree(this.selectedId).icon, "\"></i> ").concat(this.findBranchInTree(this.selectedId).label);
    },
    selectedTree: function selectedTree() {
      return this.$refs.tree.menu.current;
    }
  }),
  methods: _objectSpread(_objectSpread({}, Object(_node_modules_vuex__WEBPACK_IMPORTED_MODULE_1__["mapMutations"])(['updateValue', 'updateChecked'])), {}, {
    appendValue: function appendValue(node_id) {
      var selected = this.treeValue.slice(0);
      selected.push(node_id);
      this.updateValue(private_scope.uniqueArray(selected));
    },
    removeValue: function removeValue(node_id) {
      var selected = this.treeValue.slice(0),
          where;
      if (~(where = selected.indexOf(node_id))) selected[where] = where > 0 ? selected[0] : where != 1 && selected.length > 1 ? selected[1] : null; // refill position with duplicate values from array and

      this.updateValue(private_scope.uniqueArray(selected)); // ... it will be remove duplicated
    },
    isSelected: function isSelected(node_id) {
      return ~this.treeValue.indexOf(node_id);
    },
    delay: function delay() {
      var miliseconds = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 100;
      var callback = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
      return new Promise(function (resolve) {
        setTimeout(typeof callback == 'function' ? function () {
          callback();
          resolve();
        } : resolve, miliseconds);
      });
    },
    clearAll: function clearAll() {
      this.updateChecked({});
      this.updateValue([]);
    },
    onSelect: function onSelect(node, instanceId) {
      this.gs_data(node.id); // refreshNodeId_Array

      if (private_scope.prevSelection == node.id) // reselecting fills all checkboxes
        this.gs_data(node.id, [1, 1, 1, 1, 1, 1]);
      this.appendValue(node.id);
      this.$forceUpdate();
      this.selectedId = node.id;
      private_scope.prevSelection = this.selectedId;
      this.freshComponents();
      this.$forceUpdate();
    },
    deSelect: function deSelect(node, instanceId) {
      var _this2 = this;

      this.gs_data(node.id); // refreshNodeId_Array

      var elem;

      if (private_scope.prevSelection == node.id) {
        // reselecting clear all checkboxes
        this.gs_data(node.id, [0, 0, 0, 0, 0, 0]);
        this.removeValue(node.id);
      } else {
        // +this.gs_data(node.id).map(v=> +v).join('')
        this.delay(40, function () {
          // check Th Box for related subsytem/menu
          _this2.appendValue(node.id);

          private_scope.prevSelection = node.id;
        });
      }

      this.selectedId = node.id;
      this.$forceUpdate();
      this.freshComponents();
    },
    checkForChecklick: function checkForChecklick(event, i) {
      var _this3 = this;

      return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
        var itemProps;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return _this3.delay(5);

              case 2:
                private_scope.events[_this3.selectedId] = event.target.checked;
                _context.next = 5;
                return _this3.delay(100);

              case 5:
                itemProps = _this3.gs_data(_this3.selectedId, Object.entries(private_scope.components).map(function (v) {
                  return v[1].$el.querySelector('input').checked;
                }));

                if (!private_scope.events[_this3.selectedId]) {
                  _context.next = 13;
                  break;
                }

                if (_this3.isSelected(_this3.selectedId)) {
                  _context.next = 10;
                  break;
                }

                _context.next = 10;
                return _this3.delay(75);

              case 10:
                _this3.appendValue(_this3.selectedId);

                _context.next = 15;
                break;

              case 13:
                private_scope.events[_this3.selectedId] = true;
                if (_this3.isSelected(_this3.selectedId)) if (!+itemProps.map(function (v) {
                  return +v;
                }).join('')) // if there is no checked
                  _this3.removeValue(_this3.selectedId);

              case 15:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    resetConsole: function resetConsole() {
      var changing = false;

      for (var _i in private_scope.changing) {
        if (private_scope.changing[_i]) {
          changing = true;
          break;
        }
      }

      if (changing) return setTimeout(this.resetConsole, 10);
      console.error = private_scope.origError;
    },
    freshVal: function freshVal(elem, newVal, _index) {
      var _this4 = this;

      return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2() {
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                if (!(elem.$el.querySelector('input').checked == newVal)) {
                  _context2.next = 2;
                  break;
                }

                return _context2.abrupt("return");

              case 2:
                _context2.prev = 2;
                console.error = private_scope.nullFunc;
                private_scope.changing[_index] = true;
                elem.value = !newVal;
                _context2.next = 8;
                return _this4.delay(50);

              case 8:
                try {
                  elem.value = newVal;
                  private_scope.changing[_index] = false;
                } catch (e) {}

                setTimeout(_this4.resetConsole, 10);
                _context2.next = 14;
                break;

              case 12:
                _context2.prev = 12;
                _context2.t0 = _context2["catch"](2);

              case 14:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, null, [[2, 12]]);
      }))();
    },
    freshComponents: function freshComponents() {
      var _this5 = this;

      return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee3() {
        var _i, _checkBox, value, component;

        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                for (_i in _this5.$refs) {
                  if (~_i.indexOf('treeCheck')) private_scope.components[_i] = _this5.$refs[_i][0] || {
                    value: !0
                  };
                }

                _context3.next = 3;
                return _this5.delay(100);

              case 3:
                _context3.t0 = _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.keys(private_scope.components);

              case 4:
                if ((_context3.t1 = _context3.t0()).done) {
                  _context3.next = 12;
                  break;
                }

                _checkBox = _context3.t1.value;
                value = _this5.gs_data()[+_checkBox.match(/\d/g).join('')], component = private_scope.components[_checkBox];
                _context3.next = 9;
                return _this5.freshVal(component, value, _checkBox);

              case 9:
                component.$forceUpdate();
                _context3.next = 4;
                break;

              case 12:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }))();
    },
    gs_data: function gs_data() {
      var _this6 = this;

      var node_id = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
      var value = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
      if (!node_id) node_id = this.selectedId;
      var hasValue = true; // false if this is an "init fill"

      if (!this.checkData[node_id]) {
        value = [1, 1, 1, 1, 1, 1];
        hasValue = false;
      }

      if (value) {
        if (value.forEach) this.$vuexSet("checkData.".concat(node_id), private_scope.boolMap(value)); // this.checkData[node_id] = value;///private_scope.boolMap(value);///.forEach((state, index)=>this.checkData[node_id].splice(index,1,state)); // replace value in array by new Value

        if (this.forest.nodeMap[node_id] && this.forest.nodeMap[node_id].children) this.delay(25, function () {
          var _iterator = _createForOfIteratorHelper(_this6.forest.nodeMap[node_id].children),
              _step;

          try {
            for (_iterator.s(); !(_step = _iterator.n()).done;) {
              var childNode = _step.value;
              if (hasValue) // not autofilled
                _this6.gs_data(childNode.id, value);else if (!_this6.checkData[childNode.id]) // child has not data
                _this6.gs_data(childNode.id, value);
            }
          } catch (err) {
            _iterator.e(err);
          } finally {
            _iterator.f();
          }
        });
      }

      return this.checkData[node_id];
    },
    setTreeCheck: function setTreeCheck(node_id) {
      var state = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : -1;
      if (!~state) state = STATE_CHECKED;
      this.forest.checkedStateMap[node_id] = state;
      /*
      if(this.forest.nodeMap[node_id].children)
      this.delay(25, ()=>{
      this.forest.nodeMap[node_id].children.map((v, index) => this.forest.checkedStateMap[index]).join('').indexOf("0")
      for(let childNode of this.forest.nodeMap[node_id].children)
      	this.forest.checkedStateMap[childNode.id] = state;
      }); */
    },
    findBranchInTree: function findBranchInTree(id
    /* branch */
    ) {
      var NULL_OBJ = {
        icon: '',
        label: ''
      };
      if (typeof id != 'string') return NULL_OBJ;

      var searcher = function searcher(obj) {
        var result = NULL_OBJ;

        for (var p in obj) {
          if (obj.id === id) {
            return obj;
          } else {
            if (_typeof(obj[p]) === 'object') {
              result = searcher(obj[p]);

              if (result.label) {
                return result;
              }
            }
          }
        }

        return result;
      };

      return searcher(this.tree);
    },
    getPermissions: function getPermissions() {
      var resultPermissions = {},
          selected = this.treeValue.slice(0),
          node_id;

      for (node_id in this.checkData) {
        if (~selected.indexOf(node_id)) resultPermissions[node_id] = this.checkData[node_id];
      }

      return resultPermissions;
    }
  }),
  created: function created() {
    console.log(Vue.prototype); // console.log('#VueDeepSet', VueDeepSet);
    // console.log('iVue#', this);

    private_scope.nullFunc = private_scope.origError;
    private_scope.origError = console.error;
  },
  mounted: function mounted() {
    var _this7 = this;

    return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee4() {
      var _yield$_this7$$http$g, data;

      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee4$(_context4) {
        while (1) {
          switch (_context4.prev = _context4.next) {
            case 0:
              // console.log(this.checkData);
              _this7.$vuexSet('checkData.0', private_scope.boolMap([0, 0, 0, 0, 0, 0])); // private_scope.boolMap({0: [0,0,0,0,0,0], ...this.permissions
              // if(this.permissions)
              // 	this.checkData = private_scope.abilitiesToPermissions(this.permissions);


              _context4.next = 3;
              return _this7.$http.get("".concat(window.config.permissions_base_url, "/getTree"));

            case 3:
              _yield$_this7$$http$g = _context4.sent;
              data = _yield$_this7$$http$g.data;
              _this7.tree = data;
              _this7.forest = _this7.$refs.tree.forest;
              /* this.$nextTick(()=>{
              this.$refs.tree.$refs.menu.$children // only one level children, u can get nested level by $option.$children
              .filter(child => child.$options.name == "vue-treeselect--option")
              .every($option => );
              }); */

              window._X_find = function (branch) {
                return _this7.findBranchInTree(branch);
              };

            case 8:
            case "end":
              return _context4.stop();
          }
        }
      }, _callee4);
    }))();
  }
});
window._private_vars = private_scope;

/***/ }),

/***/ "./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!../AccessLevel/Resources/js/components/Tree.vue?vue&type=style&index=0&lang=scss&":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/sass-loader/dist/cjs.js??ref--6-3!./node_modules/vue-loader/lib??vue-loader-options!../AccessLevel/Resources/js/components/Tree.vue?vue&type=style&index=0&lang=scss& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../Panel/node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".tree-components {\n  margin-top: -15px;\n}\n.vue-treeselect__label-container:hover .vue-treeselect__checkbox--unchecked {\n  border-color: black;\n}\n.vue-treeselect__checkbox--checked,\n.vue-treeselect__label-container:hover .vue-treeselect__checkbox--checked {\n  border-color: black;\n  background: black;\n}\n.tree-container {\n  direction: ltr;\n}\n.vue-treeselect__control {\n  display: none !important;\n}\n[dir=rtl] .vue-treeselect,\n.vue-treeselect--open-below:not(.vue-treeselect--append-to-body) .vue-treeselect__menu-container {\n  position: initial;\n}\n[dir=rtl] .vue-treeselect--open-below .vue-treeselect__menu {\n  position: relative;\n  border: 0;\n}", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!../AccessLevel/Resources/js/components/Tree.vue?vue&type=style&index=0&lang=scss&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/sass-loader/dist/cjs.js??ref--6-3!./node_modules/vue-loader/lib??vue-loader-options!../AccessLevel/Resources/js/components/Tree.vue?vue&type=style&index=0&lang=scss& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../Panel/node_modules/css-loader!../../../../Panel/node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../Panel/node_modules/postcss-loader/src??ref--6-2!../../../../Panel/node_modules/sass-loader/dist/cjs.js??ref--6-3!../../../../Panel/node_modules/vue-loader/lib??vue-loader-options!./Tree.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!../AccessLevel/Resources/js/components/Tree.vue?vue&type=style&index=0&lang=scss&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../Panel/node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../AccessLevel/Resources/js/components/Tree.vue?vue&type=template&id=14dce278&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!../AccessLevel/Resources/js/components/Tree.vue?vue&type=template&id=14dce278& ***!
  \********************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "tree-components", attrs: { dir: "rtl" } },
    [
      _c(
        "vs-row",
        { staticClass: "tree-root" },
        [
          _c(
            "vs-col",
            {
              staticClass: "tree-container",
              attrs: { "vs-lg": "6", "vs-md": "6" }
            },
            [
              _c("treeselect", {
                ref: "tree",
                attrs: {
                  value: _vm.treeValue,
                  multiple: true,
                  options: _vm.tree,
                  "always-open": true,
                  "open-on-click": false,
                  "max-height": _vm.treeHeight,
                  flat: true
                },
                on: { select: _vm.onSelect, deselect: _vm.deSelect },
                scopedSlots: _vm._u([
                  {
                    key: "option-label",
                    fn: function(ref) {
                      var node = ref.node
                      var labelClassName = ref.labelClassName
                      return _c("label", { class: labelClassName }, [
                        _c("i", { class: node.raw.icon }),
                        _vm._v(
                          "\n          " + _vm._s(node.label) + "\n        "
                        )
                      ])
                    }
                  }
                ])
              })
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "vs-col",
            { attrs: { "vs-lg": "6", "vs-md": "6" } },
            [
              _c(
                "vx-card",
                { staticStyle: { "box-shadow": "none" } },
                [
                  _c("label", [
                    _vm._v("دسترسی های "),
                    _c("label", {
                      domProps: { innerHTML: _vm._s(_vm.checkBoxTitle) }
                    })
                  ]),
                  _vm._v(" "),
                  _vm._l(_vm.checkboxes, function(item, index) {
                    return _c(
                      "vs-checkbox",
                      {
                        key: index,
                        ref: "treeCheck" + index,
                        refInFor: true,
                        attrs: { color: item[1] },
                        on: {
                          change: function($event) {
                            return _vm.checkForChecklick($event, index)
                          }
                        },
                        model: {
                          value: _vm.checkData[_vm._selectedId][index],
                          callback: function($$v) {
                            _vm.$set(_vm.checkData[_vm._selectedId], index, $$v)
                          },
                          expression: "checkData[_selectedId][index]"
                        }
                      },
                      [_vm._v(_vm._s(item[0]))]
                    )
                  })
                ],
                2
              )
            ],
            1
          )
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);