(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[4],{

/***/ "../User/Resources/js/niffr_cases/Create.vue":
/*!***************************************************!*\
  !*** ../User/Resources/js/niffr_cases/Create.vue ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Create_vue_vue_type_template_id_b3414e14___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Create.vue?vue&type=template&id=b3414e14& */ "../User/Resources/js/niffr_cases/Create.vue?vue&type=template&id=b3414e14&");
/* harmony import */ var _Create_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Create.vue?vue&type=script&lang=js& */ "../User/Resources/js/niffr_cases/Create.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _Create_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Create.vue?vue&type=style&index=0&lang=css& */ "../User/Resources/js/niffr_cases/Create.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _Panel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../Panel/node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_Panel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Create_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Create_vue_vue_type_template_id_b3414e14___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Create_vue_vue_type_template_id_b3414e14___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "User/Resources/js/niffr_cases/Create.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "../User/Resources/js/niffr_cases/Create.vue?vue&type=script&lang=js&":
/*!****************************************************************************!*\
  !*** ../User/Resources/js/niffr_cases/Create.vue?vue&type=script&lang=js& ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Panel_node_modules_babel_loader_lib_index_js_ref_4_0_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Create_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../Panel/node_modules/babel-loader/lib??ref--4-0!../../../../Panel/node_modules/vue-loader/lib??vue-loader-options!./Create.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../User/Resources/js/niffr_cases/Create.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_Panel_node_modules_babel_loader_lib_index_js_ref_4_0_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Create_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "../User/Resources/js/niffr_cases/Create.vue?vue&type=style&index=0&lang=css&":
/*!************************************************************************************!*\
  !*** ../User/Resources/js/niffr_cases/Create.vue?vue&type=style&index=0&lang=css& ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Panel_node_modules_style_loader_index_js_Panel_node_modules_css_loader_index_js_ref_5_1_Panel_node_modules_vue_loader_lib_loaders_stylePostLoader_js_Panel_node_modules_postcss_loader_src_index_js_ref_5_2_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Create_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../Panel/node_modules/style-loader!../../../../Panel/node_modules/css-loader??ref--5-1!../../../../Panel/node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../Panel/node_modules/postcss-loader/src??ref--5-2!../../../../Panel/node_modules/vue-loader/lib??vue-loader-options!./Create.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!../User/Resources/js/niffr_cases/Create.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _Panel_node_modules_style_loader_index_js_Panel_node_modules_css_loader_index_js_ref_5_1_Panel_node_modules_vue_loader_lib_loaders_stylePostLoader_js_Panel_node_modules_postcss_loader_src_index_js_ref_5_2_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Create_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_Panel_node_modules_style_loader_index_js_Panel_node_modules_css_loader_index_js_ref_5_1_Panel_node_modules_vue_loader_lib_loaders_stylePostLoader_js_Panel_node_modules_postcss_loader_src_index_js_ref_5_2_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Create_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _Panel_node_modules_style_loader_index_js_Panel_node_modules_css_loader_index_js_ref_5_1_Panel_node_modules_vue_loader_lib_loaders_stylePostLoader_js_Panel_node_modules_postcss_loader_src_index_js_ref_5_2_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Create_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _Panel_node_modules_style_loader_index_js_Panel_node_modules_css_loader_index_js_ref_5_1_Panel_node_modules_vue_loader_lib_loaders_stylePostLoader_js_Panel_node_modules_postcss_loader_src_index_js_ref_5_2_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Create_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "../User/Resources/js/niffr_cases/Create.vue?vue&type=template&id=b3414e14&":
/*!**********************************************************************************!*\
  !*** ../User/Resources/js/niffr_cases/Create.vue?vue&type=template&id=b3414e14& ***!
  \**********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Panel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Create_vue_vue_type_template_id_b3414e14___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../Panel/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../Panel/node_modules/vue-loader/lib??vue-loader-options!./Create.vue?vue&type=template&id=b3414e14& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../User/Resources/js/niffr_cases/Create.vue?vue&type=template&id=b3414e14&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _Panel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Create_vue_vue_type_template_id_b3414e14___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _Panel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Create_vue_vue_type_template_id_b3414e14___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "../User/Resources/js/niffr_cases/PointTable.vue":
/*!*******************************************************!*\
  !*** ../User/Resources/js/niffr_cases/PointTable.vue ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _PointTable_vue_vue_type_template_id_47aac618___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PointTable.vue?vue&type=template&id=47aac618& */ "../User/Resources/js/niffr_cases/PointTable.vue?vue&type=template&id=47aac618&");
/* harmony import */ var _PointTable_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PointTable.vue?vue&type=script&lang=js& */ "../User/Resources/js/niffr_cases/PointTable.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _PointTable_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./PointTable.vue?vue&type=style&index=0&lang=css& */ "../User/Resources/js/niffr_cases/PointTable.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _Panel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../Panel/node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_Panel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _PointTable_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _PointTable_vue_vue_type_template_id_47aac618___WEBPACK_IMPORTED_MODULE_0__["render"],
  _PointTable_vue_vue_type_template_id_47aac618___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "User/Resources/js/niffr_cases/PointTable.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "../User/Resources/js/niffr_cases/PointTable.vue?vue&type=script&lang=js&":
/*!********************************************************************************!*\
  !*** ../User/Resources/js/niffr_cases/PointTable.vue?vue&type=script&lang=js& ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Panel_node_modules_babel_loader_lib_index_js_ref_4_0_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_PointTable_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../Panel/node_modules/babel-loader/lib??ref--4-0!../../../../Panel/node_modules/vue-loader/lib??vue-loader-options!./PointTable.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../User/Resources/js/niffr_cases/PointTable.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_Panel_node_modules_babel_loader_lib_index_js_ref_4_0_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_PointTable_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "../User/Resources/js/niffr_cases/PointTable.vue?vue&type=style&index=0&lang=css&":
/*!****************************************************************************************!*\
  !*** ../User/Resources/js/niffr_cases/PointTable.vue?vue&type=style&index=0&lang=css& ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Panel_node_modules_style_loader_index_js_Panel_node_modules_css_loader_index_js_ref_5_1_Panel_node_modules_vue_loader_lib_loaders_stylePostLoader_js_Panel_node_modules_postcss_loader_src_index_js_ref_5_2_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_PointTable_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../Panel/node_modules/style-loader!../../../../Panel/node_modules/css-loader??ref--5-1!../../../../Panel/node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../Panel/node_modules/postcss-loader/src??ref--5-2!../../../../Panel/node_modules/vue-loader/lib??vue-loader-options!./PointTable.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!../User/Resources/js/niffr_cases/PointTable.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _Panel_node_modules_style_loader_index_js_Panel_node_modules_css_loader_index_js_ref_5_1_Panel_node_modules_vue_loader_lib_loaders_stylePostLoader_js_Panel_node_modules_postcss_loader_src_index_js_ref_5_2_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_PointTable_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_Panel_node_modules_style_loader_index_js_Panel_node_modules_css_loader_index_js_ref_5_1_Panel_node_modules_vue_loader_lib_loaders_stylePostLoader_js_Panel_node_modules_postcss_loader_src_index_js_ref_5_2_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_PointTable_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _Panel_node_modules_style_loader_index_js_Panel_node_modules_css_loader_index_js_ref_5_1_Panel_node_modules_vue_loader_lib_loaders_stylePostLoader_js_Panel_node_modules_postcss_loader_src_index_js_ref_5_2_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_PointTable_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _Panel_node_modules_style_loader_index_js_Panel_node_modules_css_loader_index_js_ref_5_1_Panel_node_modules_vue_loader_lib_loaders_stylePostLoader_js_Panel_node_modules_postcss_loader_src_index_js_ref_5_2_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_PointTable_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "../User/Resources/js/niffr_cases/PointTable.vue?vue&type=template&id=47aac618&":
/*!**************************************************************************************!*\
  !*** ../User/Resources/js/niffr_cases/PointTable.vue?vue&type=template&id=47aac618& ***!
  \**************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Panel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_PointTable_vue_vue_type_template_id_47aac618___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../Panel/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../Panel/node_modules/vue-loader/lib??vue-loader-options!./PointTable.vue?vue&type=template&id=47aac618& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../User/Resources/js/niffr_cases/PointTable.vue?vue&type=template&id=47aac618&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _Panel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_PointTable_vue_vue_type_template_id_47aac618___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _Panel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_PointTable_vue_vue_type_template_id_47aac618___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "../User/Resources/js/niffr_cases/Points.vue":
/*!***************************************************!*\
  !*** ../User/Resources/js/niffr_cases/Points.vue ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Points_vue_vue_type_template_id_bd706d46___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Points.vue?vue&type=template&id=bd706d46& */ "../User/Resources/js/niffr_cases/Points.vue?vue&type=template&id=bd706d46&");
/* harmony import */ var _Points_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Points.vue?vue&type=script&lang=js& */ "../User/Resources/js/niffr_cases/Points.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _Points_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Points.vue?vue&type=style&index=0&lang=css& */ "../User/Resources/js/niffr_cases/Points.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _Panel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../Panel/node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_Panel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Points_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Points_vue_vue_type_template_id_bd706d46___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Points_vue_vue_type_template_id_bd706d46___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "User/Resources/js/niffr_cases/Points.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "../User/Resources/js/niffr_cases/Points.vue?vue&type=script&lang=js&":
/*!****************************************************************************!*\
  !*** ../User/Resources/js/niffr_cases/Points.vue?vue&type=script&lang=js& ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Panel_node_modules_babel_loader_lib_index_js_ref_4_0_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Points_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../Panel/node_modules/babel-loader/lib??ref--4-0!../../../../Panel/node_modules/vue-loader/lib??vue-loader-options!./Points.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../User/Resources/js/niffr_cases/Points.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_Panel_node_modules_babel_loader_lib_index_js_ref_4_0_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Points_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "../User/Resources/js/niffr_cases/Points.vue?vue&type=style&index=0&lang=css&":
/*!************************************************************************************!*\
  !*** ../User/Resources/js/niffr_cases/Points.vue?vue&type=style&index=0&lang=css& ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Panel_node_modules_style_loader_index_js_Panel_node_modules_css_loader_index_js_ref_5_1_Panel_node_modules_vue_loader_lib_loaders_stylePostLoader_js_Panel_node_modules_postcss_loader_src_index_js_ref_5_2_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Points_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../Panel/node_modules/style-loader!../../../../Panel/node_modules/css-loader??ref--5-1!../../../../Panel/node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../Panel/node_modules/postcss-loader/src??ref--5-2!../../../../Panel/node_modules/vue-loader/lib??vue-loader-options!./Points.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!../User/Resources/js/niffr_cases/Points.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _Panel_node_modules_style_loader_index_js_Panel_node_modules_css_loader_index_js_ref_5_1_Panel_node_modules_vue_loader_lib_loaders_stylePostLoader_js_Panel_node_modules_postcss_loader_src_index_js_ref_5_2_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Points_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_Panel_node_modules_style_loader_index_js_Panel_node_modules_css_loader_index_js_ref_5_1_Panel_node_modules_vue_loader_lib_loaders_stylePostLoader_js_Panel_node_modules_postcss_loader_src_index_js_ref_5_2_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Points_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _Panel_node_modules_style_loader_index_js_Panel_node_modules_css_loader_index_js_ref_5_1_Panel_node_modules_vue_loader_lib_loaders_stylePostLoader_js_Panel_node_modules_postcss_loader_src_index_js_ref_5_2_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Points_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _Panel_node_modules_style_loader_index_js_Panel_node_modules_css_loader_index_js_ref_5_1_Panel_node_modules_vue_loader_lib_loaders_stylePostLoader_js_Panel_node_modules_postcss_loader_src_index_js_ref_5_2_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Points_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "../User/Resources/js/niffr_cases/Points.vue?vue&type=template&id=bd706d46&":
/*!**********************************************************************************!*\
  !*** ../User/Resources/js/niffr_cases/Points.vue?vue&type=template&id=bd706d46& ***!
  \**********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Panel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Points_vue_vue_type_template_id_bd706d46___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../Panel/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../Panel/node_modules/vue-loader/lib??vue-loader-options!./Points.vue?vue&type=template&id=bd706d46& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../User/Resources/js/niffr_cases/Points.vue?vue&type=template&id=bd706d46&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _Panel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Points_vue_vue_type_template_id_bd706d46___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _Panel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_Panel_node_modules_vue_loader_lib_index_js_vue_loader_options_Points_vue_vue_type_template_id_bd706d46___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "../User/Resources/js/niffr_cases/all_points.js":
/*!******************************************************!*\
  !*** ../User/Resources/js/niffr_cases/all_points.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  "LM_OSTIAL": {
    "position": "0.29230763221275413m 0.1632841509086988m 0.07139593915393697m",
    "normal": "0.9711708855156178m 0.1541834634979456m -0.1818091601393846m",
    "visibility-attribute": "visible",
    "label": "LM OSTIAL",
    "name": "LM_OSTIAL",
    "vessel": "LM",
    "region": "OSTIAL"
  },
  "LM_DISTAL": {
    "position": "0.30792571808573277m 0.14507550974047634m 0.11883588237895723m",
    "normal": "0.9366079762833974m 0.3500385176733865m 0.01544457533690471m",
    "visibility-attribute": "visible",
    "label": "LM DISTAL",
    "name": "LM_DISTAL",
    "vessel": "LM",
    "region": "DISTAL"
  },
  "LAD_OSTIAL": {
    "position": "0.32909152865197877m 0.11633500365039724m 0.15194304425170868m",
    "normal": "0.8437969938204799m 0.5170677952555434m -0.14369247833165313m",
    "visibility-attribute": "visible",
    "label": "LAD OSTIAL",
    "name": "LAD_OSTIAL",
    "vessel": "LAD",
    "region": "OSTIAL"
  },
  "LAD_PROXIMAL": {
    "position": "0.3695550475443147m 0.06367153351988768m 0.2014584473360373m",
    "normal": "0.870695993439877m 0.40979707620729017m -0.27194639791639463m",
    "visibility-attribute": "visible",
    "label": "LAD PROXIMAL",
    "name": "LAD_PROXIMAL",
    "vessel": "LAD",
    "region": "PROXIMAL"
  },
  "LAD_MID_PART": {
    "position": "0.4098292433175047m -0.016395445390416152m 0.4453843592941024m",
    "normal": "0.980783660387004m 0.18217773904102075m 0.06981892949460027m",
    "visibility-attribute": "visible",
    "label": "LAD MID PART",
    "name": "LAD_MID_PART",
    "vessel": "LAD",
    "region": "MID PART"
  },
  "LAD_DISTAL": {
    "position": "0.35698283090534394m -0.17323511690518623m 0.6998857082341631m",
    "normal": "0.8969156050795585m 0.14854908209630763m 0.41650398266176764m",
    "visibility-attribute": "visible",
    "label": "LAD DISTAL",
    "name": "LAD_DISTAL",
    "vessel": "LAD",
    "region": "DISTAL"
  },
  "DIAGONAL_2": {
    "position": "0.4218183504015556m -0.09182736981690182m 0.5592602808437199m",
    "normal": "0.35812018093919856m 0.22452136925590319m 0.9062781530807913m",
    "visibility-attribute": "visible",
    "label": "DIAGONAL 2",
    "name": "DIAGONAL_2",
    "vessel": "DIAGONAL 2"
  },
  "Dig_OSTIAL": {
    "position": "0.4220019120071351m -0.01878174528064748m 0.36158172553046986m",
    "normal": "0.8707969366931463m 0.36141126634408055m 0.3333085531536816m",
    "visibility-attribute": "visible",
    "label": "Dig OSTIAL",
    "name": "Dig_OSTIAL",
    "vessel": "Dig",
    "region": "OSTIAL"
  },
  "Dig_PROXIMAL": {
    "position": "0.43715181970072625m -0.06426058413413524m 0.40188219780230117m",
    "normal": "0.9974440033186937m 0.0528642805484142m -0.04807107327360586m",
    "visibility-attribute": "visible",
    "label": "Dig PROXIMAL",
    "name": "Dig_PROXIMAL",
    "vessel": "Dig",
    "region": "PROXIMAL"
  },
  "LCX_OSTIAL": {
    "position": "0.3194179164698847m -0.010706087587260715m 0.02921884617190773m",
    "normal": "0.6716753567516066m -0.05386152413723659m -0.7388850731678209m",
    "visibility-attribute": "visible",
    "label": "LCX OSTIAL",
    "name": "LCX_OSTIAL",
    "vessel": "LCX",
    "region": "OSTIAL"
  },
  "LCX_MID_PART": {
    "position": "0.23382446102681775m -0.144046266474874m -0.009330213045604274m",
    "normal": "0.7661681275809329m -0.2192472551131038m -0.6040836377559793m",
    "visibility-attribute": "visible",
    "label": "LCX MID PART",
    "name": "LCX_MID_PART",
    "vessel": "LCX",
    "region": "MID PART"
  },
  "OM2_OSTIAL": {
    "position": "0.3406990808494615m -0.24682424944182668m 0.0565424565634135m",
    "normal": "0.7556229357725606m -0.32637154648381944m -0.5679045629154753m",
    "visibility-attribute": "visible",
    "label": "OM2 OSTIAL",
    "name": "OM2_OSTIAL",
    "vessel": "OM2",
    "region": "OSTIAL"
  },
  "OM2_PROXIMAL": {
    "position": "0.374728003292535m -0.29104066532055456m 0.10670563469491268m",
    "normal": "0.4093695393770095m -0.7420909774850769m -0.530770723915231m",
    "visibility-attribute": "visible",
    "label": "OM2 PROXIMAL",
    "name": "OM2_PROXIMAL",
    "vessel": "OM2",
    "region": "PROXIMAL"
  },
  "OM2_MID_PART": {
    "position": "0.45089731943637057m -0.2953048843268309m 0.237842818263425m",
    "normal": "0.7877687068924033m -0.5579434843797414m -0.2609971890255984m",
    "visibility-attribute": "visible",
    "label": "OM2 MID PART",
    "name": "OM2_MID_PART",
    "vessel": "OM2",
    "region": "MID PART"
  },
  "OM1_OSTIAL": {
    "position": "0.3316397593033336m -0.05718886925269001m 0.030126200524684954m",
    "normal": "0.3720353039690471m 0.17107325749066868m -0.9123177479212987m",
    "visibility-attribute": "visible",
    "label": "OM1 OSTIAL",
    "name": "OM1_OSTIAL",
    "vessel": "OM1",
    "region": "OSTIAL"
  },
  "OM1_PROXIMAL": {
    "position": "0.41155826368160897m -0.10915732711682946m 0.0783351704184318m",
    "normal": "0.7224955373944705m -0.009330049498480803m -0.6913126272689016m",
    "visibility-attribute": "visible",
    "label": "OM1 PROXIMAL",
    "name": "OM1_PROXIMAL",
    "vessel": "OM1",
    "region": "PROXIMAL"
  },
  "OM1_MID_PART": {
    "position": "0.4690607991927551m -0.16783226877006202m 0.19041940052629305m",
    "normal": "0.9588698754217713m -0.022633339168911113m -0.2829422095882865m",
    "visibility-attribute": "visible",
    "label": "OM1 MID PART",
    "name": "OM1_MID_PART",
    "vessel": "OM1",
    "region": "MID PART"
  },
  "OM1_DISTAL": {
    "position": "0.4849582870988952m -0.22344747939208476m 0.2941774067320132m",
    "normal": "0.9999659911067593m -0.008129378342525416m -0.0013891859633047637m",
    "visibility-attribute": "visible",
    "label": "OM1 DISTAL",
    "name": "OM1_DISTAL",
    "vessel": "OM1",
    "region": "DISTAL"
  },
  "RCA_OSTIAL": {
    "position": "0.04413793937909383m 0.16359165762840988m 0.23831982661424134m",
    "normal": "0.4358678916554991m 0.770190443932328m 0.465645638977875m",
    "visibility-attribute": "visible",
    "label": "RCA OSTIAL",
    "name": "RCA_OSTIAL",
    "vessel": "RCA",
    "region": "OSTIAL"
  },
  "RCA_PROXIMAL": {
    "position": "-0.04976129800842244m 0.1411358322756855m 0.2844561782385679m",
    "normal": "-0.42399947374886965m 0.8313810838802999m 0.35920737691018995m",
    "visibility-attribute": "visible",
    "label": "RCA PROXIMAL",
    "name": "RCA_PROXIMAL",
    "vessel": "RCA",
    "region": "PROXIMAL"
  },
  "RCA_MID_PART": {
    "position": "-0.1547995199819202m 0.0020512232162371302m 0.3504933725283198m",
    "normal": "-0.8110064411333926m 0.41888555621494666m 0.40841577250963707m",
    "visibility-attribute": "visible",
    "label": "RCA MID PART",
    "name": "RCA_MID_PART",
    "vessel": "RCA",
    "region": "MID PART"
  },
  "RCA_DISTAL": {
    "position": "-0.15536984347856264m -0.28736227920451657m 0.3082246519786328m",
    "normal": "-0.7638059220715093m -0.49536925044485086m 0.4137750827710608m",
    "visibility-attribute": "visible",
    "label": "RCA DISTAL",
    "name": "RCA_DISTAL",
    "vessel": "RCA",
    "region": "DISTAL"
  },
  "PLV_OSTIAL": {
    "position": "0.011715229804953708m -0.40700728407913955m 0.20806619070206692m",
    "normal": "-0.5733246830735588m -0.7424585513079112m -0.34648824997157035m",
    "visibility-attribute": "visible",
    "label": "PLV OSTIAL",
    "name": "PLV_OSTIAL",
    "vessel": "PLV",
    "region": "OSTIAL"
  },
  "PLV_PROXIMAL": {
    "position": "0.0152815623403727m -0.42690212789326887m 0.27791128067005716m",
    "normal": "-0.6887216732454231m -0.7078177601755619m -0.15702380450771028m",
    "visibility-attribute": "visible",
    "label": "PLV PROXIMAL",
    "name": "PLV_PROXIMAL",
    "vessel": "PLV",
    "region": "PROXIMAL"
  },
  "PLV_MID_PART": {
    "position": "0.08211476675911866m -0.4564478007373898m 0.3943582848364673m",
    "normal": "-0.20813872063532726m -0.9777904698087028m -0.024577838057191933m",
    "visibility-attribute": "visible",
    "label": "PLV MID PART",
    "name": "PLV_MID_PART",
    "vessel": "PLV",
    "region": "MID PART"
  },
  "PLV_DISTAL": {
    "position": "0.15637260972949515m -0.4629884751581601m 0.5061967996724931m",
    "normal": "-0.09977972425612237m -0.9934207462391016m 0.05620700640595281m",
    "visibility-attribute": "visible",
    "label": "PLV DISTAL",
    "name": "PLV_DISTAL",
    "vessel": "PLV",
    "region": "DISTAL"
  },
  "PDA_OSTIAL": {
    "position": "0.11701451443713498m -0.35809466562691883m 0.07396544514151937m",
    "normal": "-0.18673750398972372m -0.9478242027751882m -0.25837644094860335m",
    "visibility-attribute": "visible",
    "label": "PDA OSTIAL",
    "name": "PDA_OSTIAL",
    "region": "OSTIAL",
    "vessel": "PDA"
  },
  "PDA_PROXIMAL": {
    "position": "0.16982531761687894m -0.42570547718014284m 0.13146993636598497m",
    "normal": "0.009913007511742306m -0.7979259672167119m -0.602673944287744m",
    "visibility-attribute": "visible",
    "label": "PDA PROXIMAL",
    "name": "PDA_PROXIMAL",
    "region": "PROXIMAL",
    "vessel": "PDA"
  },
  "PDA_MID_PART": {
    "position": "0.17061707853687963m -0.4703796656771768m 0.2645840730153348m",
    "normal": "-0.3033565306246624m -0.9522105933667576m 0.035634270127165496m",
    "visibility-attribute": "visible",
    "label": "PDA MID PART",
    "name": "PDA_MID_PART",
    "vessel": "PDA",
    "region": "MID PART"
  },
  "PD": {
    "position": "0.28492069905844686m -0.4926617051703226m 0.36777019681317574m",
    "normal": "-0.09328455985256594m -0.981477449206097m 0.16733202799525984m",
    "visibility-attribute": "visible",
    "label": "PD",
    "name": "PD",
    "vessel": "PD"
  }
});

/***/ }),

/***/ "../User/Resources/js/niffr_cases/frag.js":
/*!************************************************!*\
  !*** ../User/Resources/js/niffr_cases/frag.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

var $fakeParent = Symbol();

function setFakeParent(node, fakeParent) {
  if (!node[$fakeParent]) {
    node[$fakeParent] = fakeParent;
    Object.defineProperty(node, 'parentNode', {
      get: function get() {
        return this[$fakeParent] || this.parentElement;
      }
    });
  }
}

var resetChildren = function resetChildren(frag, moveTo) {
  var nodes = frag.splice(0);
  moveTo.append.apply(moveTo, _toConsumableArray(nodes));
  nodes.forEach(function (node) {
    node[$fakeParent] = undefined;
  });
};

function insertBefore(newNode, refNode) {
  if (this.frag) {
    var idx = this.frag.indexOf(refNode);

    if (idx > -1) {
      this.frag.splice(idx, 0, newNode);
    }
  }

  if (this[$fakeChildren]) {
    var hasFakeChildren = this[$fakeChildren].get(refNode);

    if (hasFakeChildren) {
      refNode = hasFakeChildren[0];
    }
  }

  refNode.before(newNode);
  setFakeParent(newNode, this);
}

function removeChild(node) {
  if (this.frag) {
    var idx = this.frag.indexOf(node);

    if (idx > -1) {
      this.frag.splice(idx, 1);
    }
  }

  var fc = this[$fakeChildren];

  if (fc) {
    var hasFakeChildren = fc.get(node);

    if (hasFakeChildren) {
      resetChildren(hasFakeChildren, node);
      fc["delete"](node);
      node[$fakeParent] = undefined;
      return;
    }
  }

  node.remove();
}

var $fakeChildren = Symbol();
var parentPatches = {
  insertBefore: insertBefore,
  removeChild: removeChild
};

function patchParent(parent, child, nodes) {
  if (!parent[$fakeChildren]) {
    parent[$fakeChildren] = new Map();
    Object.assign(parent, parentPatches);
  }

  parent[$fakeChildren].set(child, nodes);
}

var $placeholder = Symbol();
var elementPatches = {
  insertBefore: insertBefore,
  before: function before(newNode) {
    this.frag[0].before(newNode);
  },
  remove: function remove() {
    var placeholder = this[$placeholder];
    var frag = this.frag;
    var removed = frag.splice(0, frag.length, placeholder);
    removed[0].before(this[$placeholder]);
    removed.forEach(function (element) {
      return element.remove();
    });
  },
  removeChild: removeChild,
  appendChild: function appendChild(node) {
    var length = this.frag.length;
    this.frag[length - 1].after(node);
    var placeholder = this[$placeholder];

    if (this.frag[0] === placeholder) {
      this.frag.splice(0, 1);
      placeholder.remove();
    }

    setFakeParent(node, this);
    this.frag.push(node);
  }
};
var frag = {
  inserted: function inserted(element) {
    var nodes = Array.from(element.childNodes);
    var parent = element.parentNode;
    var placeholder = document.createComment('');
    element[$placeholder] = placeholder;

    if (nodes.length === 0) {
      nodes.push(placeholder);
    }

    var fragment = document.createDocumentFragment();
    fragment.append.apply(fragment, _toConsumableArray(nodes));
    element.replaceWith(fragment);
    element.frag = nodes;
    patchParent(parent, element, nodes);
    setFakeParent(element, parent);
    nodes.forEach(function (node) {
      return setFakeParent(node, element);
    }); // Handle v-html

    Object.defineProperty(element, 'innerHTML', {
      set: function set(htmlString) {
        var domify = document.createElement('div');
        domify.innerHTML = htmlString;
        var oldNodesIdx = element.frag.length; // eslint-disable-next-line unicorn/prefer-node-append

        Array.from(domify.childNodes).forEach(function (node) {
          return element.appendChild(node);
        });
        domify.append.apply(domify, _toConsumableArray(element.frag.splice(0, oldNodesIdx)));
      },
      get: function get() {
        return '';
      }
    });
    Object.assign(element, elementPatches);
  },
  unbind: function unbind(element) {
    resetChildren(element.frag, element);
    element[$placeholder].remove();
  }
};
/* harmony default export */ __webpack_exports__["default"] = (frag);

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../User/Resources/js/niffr_cases/Create.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!../User/Resources/js/niffr_cases/Create.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/Form */ "./Resources/js/src/Form.js");
/* harmony import */ var _mixins_HasForm__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/mixins/HasForm */ "./Resources/js/src/mixins/HasForm.js");
/* harmony import */ var _Points_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Points.vue */ "../User/Resources/js/niffr_cases/Points.vue");
/* harmony import */ var _all_points__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./all_points */ "../User/Resources/js/niffr_cases/all_points.js");
/* harmony import */ var _PointTable__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./PointTable */ "../User/Resources/js/niffr_cases/PointTable.vue");


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




 // import CreatePatientModal from '../components/CreatePatientModal.vue'

/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    Points: _Points_vue__WEBPACK_IMPORTED_MODULE_3__["default"],
    PointTable: _PointTable__WEBPACK_IMPORTED_MODULE_5__["default"]
  },
  mixins: [_mixins_HasForm__WEBPACK_IMPORTED_MODULE_2__["default"]],
  data: function data() {
    var lang = this.$i18n;

    var user = _objectSpread({}, this.$store.state.auth.userInfo);

    var data = {
      ld: "",
      form: {
        file: "",
        patient_id: "",
        physician: "",
        name: "",
        age: "",
        sex: "1",
        hospital: user.name
      },
      createdCase: null,
      isLoading: false,
      showPoints: false,
      points: {},
      niffr_case_id: "",
      ctCaseResults: {},
      resultPopupActive: false,
      showCreatePatientModal: false,
      tfc: "",
      pressureForm: {
        dbp: "",
        sbp: "",
        hr: "",
        // ld:"",
        pressure: ""
      },
      patient: {},
      patients: [],
      pointsErrors: {},
      selectedPoint: {},
      pointInputPopupActive: false,
      niffer_tos: false,
      pointsKey: 0,
      noticePopupOpen: false,
      model: "Modules\\User\\Models\\NIFFRCase",
      locale: lang.locale,
      frame_number: 7.5,
      inputs: {
        name: {
          type: "vs-input"
        },
        physician: {
          type: "vs-input"
        },
        age: {
          type: "vs-input"
        },
        sex: {
          type: "vs-radio"
        },
        hospital: {
          type: "vs-input"
        },
        file: {
          type: "vs-input"
        },
        patient_id: {
          field_type: "relation",
          options: [],
          selected: {},
          foreign_key: "patient_id",
          relation_name: "patient",
          searchUrl: "/user/api/patients",
          titleField: "name"
        }
      }
    };
    return data;
  },
  props: {//
  },
  computed: {//
  },
  created: function created() {
    var _this = this;

    return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
      var nifferTos;
      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return _this.getPatients();

            case 2:
              nifferTos = localStorage.getItem("niffer_tos");
              _this.niffer_tos = !!nifferTos;
              _this.noticePopupOpen = !_this.niffer_tos; // Iracode.$on("saveNiffr",async()=>{
              //     this.calculateAll();
              //     Iracode.loading();
              //     try{
              //         const {data}=await this.$http.post(this.url("user/api/niffr_cases"),{
              //             points:this.points,
              //             patient_id:this.patient.id
              //         })
              //         if(data.success){
              //             Iracode.success(data.message)
              //             Iracode.close_loading();
              //             return this.resultPopupActive=true;
              //         }
              //         Iracode.error(data.message)
              //     }catch(e){
              //         Iracode.error(data.message)
              //     }finally{
              //         Iracode.close_loading();
              //     }
              // })

            case 5:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }))();
  },
  beforeMount: function beforeMount() {
    var modelViewerScript = document.createElement('script');
    modelViewerScript.setAttribute('src', this.url("vendor/user/js/model-viewer.min.js"));
    modelViewerScript.setAttribute('type', 'module');
    document.head.appendChild(modelViewerScript); //   scene-graph-ready
  },
  mounted: function mounted() {
    var _this2 = this;

    if (this.$refs['modelViewer']) {
      this.$refs['modelViewer'].addEventListener("load", function (e) {
        _this2.showPoints = true;
      });
    }
  },
  methods: {
    submitTos: function submitTos() {
      if (!this.niffer_tos) {
        return;
      }

      localStorage.setItem("niffer_tos", this.niffer_tos);
      this.noticePopupOpen = false;
    },
    exportAsWord: function exportAsWord(name) {
      var _this3 = this;

      return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2() {
        var point, _yield$_this3$$http$g, blob, url, a, clickHandler;

        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                point = _this3.ctCaseResults[name];

                if (point.result_file) {
                  _context2.next = 3;
                  break;
                }

                return _context2.abrupt("return");

              case 3:
                _this3.$vs.loading();

                _context2.next = 6;
                return _this3.$http.get(_this3.url(point.result_file), {
                  responseType: 'blob' // important

                });

              case 6:
                _yield$_this3$$http$g = _context2.sent;
                blob = _yield$_this3$$http$g.data;
                // Create an object URL for the blob object
                url = URL.createObjectURL(blob); // Create a new anchor element

                a = document.createElement('a'); // Set the href and download attributes for the anchor element
                // You can optionally set other attributes like `title`, etc
                // Especially, if the anchor element will be attached to the DOM

                a.href = url;
                a.download = Iracode.basename(point.result_file); // Click handler that releases the object URL after the element has been clicked
                // This is required for one-off downloads of the blob content

                clickHandler = function clickHandler(e) {
                  console.log(e);
                  setTimeout(function () {
                    URL.revokeObjectURL(url); // this.removeEventListener('click', clickHandler);

                    _this3.$vs.loading.close();
                  }, 150);
                }; // Add the click event listener on the anchor element
                // Comment out this line if you don't want a one-off download of the blob content


                a.addEventListener('click', clickHandler, false); // Programmatically trigger a click on the anchor element
                // Useful if you want the download to happen automatically
                // Without attaching the anchor element to the DOM
                // Comment out this line if you don't want an automatic download of the blob content

                a.click(); // Return the anchor element
                // Useful if you want a reference to the element
                // in order to attach it to the DOM or use it in some other way

                return _context2.abrupt("return", a);

              case 16:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    saveNiffr: function saveNiffr() {
      var _this4 = this;

      return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee3() {
        var _yield$_this4$$http$p, patient, _yield$_this4$$http$p2, data;

        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _this4.resultPopupActive = true;
                _this4.isLoading = true; // Iracode.loading();

                _context3.next = 4;
                return _this4.$http.post("/user/api/patients", _this4.form);

              case 4:
                _yield$_this4$$http$p = _context3.sent;
                patient = _yield$_this4$$http$p.data;

                _this4.calculateAll(); // if(!this.patient.id) {
                //     return Iracode.error(this.__("You have to specify a patient"))
                // }


                console.log("patient", patient);
                _context3.prev = 8;
                _context3.next = 11;
                return _this4.$http.post(_this4.url("user/api/niffr_cases"), {
                  points: _this4.points,
                  patient_id: patient.data.id,
                  map: _this4.pressureForm.pressure,
                  physician: _this4.form.physician,
                  niffr_case_id: _this4.niffr_case_id // result:this.points

                });

              case 11:
                _yield$_this4$$http$p2 = _context3.sent;
                data = _yield$_this4$$http$p2.data;

                if (data.success) {
                  Iracode.success(data.message); // Iracode.close_loading();

                  setTimeout(function () {
                    try {
                      _this4.ctCaseResults = data.data.points;
                      _this4.niffr_case_id = data.data["case"].id;
                    } catch (e) {
                      console.log(data, e);
                    }

                    _this4.isLoading = false;
                  }, 500);
                } else {
                  Iracode.error(data.message);
                }

                _context3.next = 19;
                break;

              case 16:
                _context3.prev = 16;
                _context3.t0 = _context3["catch"](8);

                if (_context3.t0.response) {
                  Iracode.error(_context3.t0.response.data.message);
                }

              case 19:
                _context3.prev = 19;
                return _context3.finish(19);

              case 21:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, null, [[8, 16, 19, 21]]);
      }))();
    },
    renderStatus: function renderStatus(point) {
      var status = "Non-Significant";
      console.log(point);

      if (point.ffr < 0.8) {
        status = "Significant";
      }

      return status;
    },
    onPatientCreated: function onPatientCreated(patient) {
      var _this5 = this;

      return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee4() {
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _this5.showCreatePatientModal = false;
                _context4.next = 3;
                return _this5.getPatients();

              case 3:
                _this5.patient = patient;

              case 4:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4);
      }))();
    },
    getPatients: function getPatients() {
      var _this6 = this;

      return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee5() {
        var _yield$_this6$$http$g, data;

        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.next = 2;
                return _this6.$http.get("/user/api/patients");

              case 2:
                _yield$_this6$$http$g = _context5.sent;
                data = _yield$_this6$$http$g.data;
                _this6.patients = data.data.items;

              case 5:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5);
      }))();
    },
    calculateAll: function calculateAll() {
      var _this7 = this;

      return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee6() {
        var key;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                if (_this7.pressureForm.pressure) {
                  _context6.next = 2;
                  break;
                }

                return _context6.abrupt("return", Iracode.error(_this7.__("You have to specify parameters needed for MAP")));

              case 2:
                for (key in _this7.points) {
                  _this7.calculate(key, _this7.points[key]);
                }

              case 3:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6);
      }))();
    },
    calculate: function calculate(key, point) {
      var PI = 3.141592;
      var MAP = parseFloat(this.pressureForm.pressure) * 133.3;
      var SBP = parseFloat(this.pressureForm.sbp);
      var HR = parseFloat(this.pressureForm.hr);
      var Ds = parseFloat(point.values.ds);
      var Dp = parseFloat(point.values.dp);
      var Dd = parseFloat(point.values.dd);
      var Ll = parseFloat(point.values.ll);
      var Ld = parseFloat(this.ld);
      var Ls = Ll;
      var Lp = 0;
      var TFC = parseFloat(this.tfc);
      var TTFC = TFC; // Ds = ((2 * Ds1) + Ds2) / 3;

      Ds = Ds * 1e-3;
      Dp = Dp * 1e-3;
      Dd = Dd * 1e-3;
      Ls = Ls * 1e-3;
      Ld = Ld * 1e-3; // Calculation of Mean of Diameter:

      var Dm = (2 * Dp + Dd) / 3; // Calulation of Area:

      var As = PI / 4 * Math.pow(Ds, 2);
      var Ad = PI / 4 * Math.pow(Dd, 2);
      var Ap = PI / 4 * Math.pow(Dp, 2);
      var Am = PI / 4 * Math.pow(Dm, 2);
      var rAPV = 0.0009 * SBP * HR + 5.925;
      var Lenght = 150 * 1e-3;
      var CFR = 2;
      var Age = this.form.age;
      console.log(point, "point");

      if (point.vessel == "LAD" || point.vessel == "DIAGONAL 2" || point.vessel == "Dig") {
        Lenght = 160 * 1e-3;
        CFR = Math.pow(10, 1.16 - 0.48 * Math.log10(rAPV) - 0.0025 * Age);

        if (TFC < 14) {
          TFC = 14;
        }

        if (TTFC < 7.5) {
          TTFC = 7.5;
        }
      } else if (point.vessel == "LCX" || point.vessel == "OM1" || point.vessel == "OM2") {
        Lenght = 120 * 1e-3;
        CFR = Math.pow(10, 1.14 - 0.45 * Math.log10(rAPV) - 0.0031 * Age);

        if (TFC < 9) {
          TFC = 9;
        }

        if (TTFC < 6) {
          TTFC = 6;
        }
      } else if (point.vessel == "RCA" || point.vessel == "PDA" || point.vessel == "PLV") {
        Lenght = 107 * 1e-3;
        CFR = Math.pow(10, 1.15 - 0.50 * Math.log10(rAPV) - 0.0021 * Age);

        if (TFC < 9) {
          TFC = 9;
        }

        if (TTFC < 6) {
          TTFC = 6;
        }
      }

      var AFDN = 15;
      AFDN = this.frame_number;
      console.log(AFDN); // if (radioButton2.Checked)
      // {
      //     AFDN = 15.0;
      // }
      // else if (radioButton3.Checked)
      // {
      //     AFDN = 25.0;
      // }
      // else if (radioButton7.Checked)
      // {
      //     AFDN = 30.0;
      // }
      // Caliculation of Mean of Velocity (Vm):

      var Vm;

      if (AFDN == 7.5) {
        Vm = Lenght * AFDN / TTFC;
      } else if (AFDN == 15) {
        Vm = Lenght * AFDN / TFC;
      } // Caliculation of Flow of the rest state (Qr):


      var Qr = Vm * Am; // Total Coronary Resistance Index (TCRI)

      var TCRI = 0.21; // Caliculation of Flow of the hyperemia state (Qh):

      var Qh = Qr / TCRI;
      var Density = 1060;
      var Viscosity = 0.0035; // debugger;
      // Calculation of Pressure Drop of hypermia state:

      var DeltaPh_eddy = Density * Math.pow(Qh, 2) * Math.pow(1 / As - 1 / Am, 2) / 2;
      var DeltaPh_proxim = 8 * PI * Viscosity * Lp * Qh / Math.pow(Ap, 2);
      var DeltaPh_distal = 8 * PI * Viscosity * Ld * Qh / Math.pow(Ad, 2);
      var DeltaPh_stenos = 8 * PI * Viscosity * Ls * Qh / Math.pow(As, 2);
      var DeltaPh = DeltaPh_eddy + DeltaPh_proxim + DeltaPh_distal + DeltaPh_stenos; // Calculation of Pressure Drop of rest state:

      var DeltaPrs = Density * Math.pow(Qr, 2) * Math.pow(1 / As - 1 / Am, 2) / 2;
      var DeltaPrr = 8 * PI * Viscosity * Ls * Qr / Math.pow(Am, 2);
      var DeltaPr = DeltaPrs + DeltaPrr; // Calculation of Fractional Flow Reserved (FFR):

      var FFR = (12888.777 - DeltaPh) / 12888.777;

      if (FFR > 0.40 & FFR < 0.75) {
        FFR = 0.2817 * FFR + 0.547;
      }

      if (FFR < 0.40) {
        FFR = 0.65;
      } // Calculation of Wall Shear Stress (WSS):


      var WSS = 4 * Viscosity * Qr / (PI * Math.pow(Ds / 2, 3));
      var Dss = (Dm - Ds) / Dm * 100;
      var Ass = (Math.pow(Dm, 2) - Math.pow(Ds, 2)) / Math.pow(Dm, 2) * 100;
      var GP = (MAP - DeltaPh) / 133.3; // Calculation of Index of Microvascular Resistance:

      var IMR = (MAP - DeltaPh) / Qh * (1e-6 / 133.3); // debugger;

      this.points[point.name].ffr = FFR.toFixed(2);
      this.points[point.name].wss = WSS.toFixed(2);
      this.points[point.name].imr = IMR.toFixed(2);
      this.points[point.name].dss = Dss.toFixed(2);
      this.points[point.name].ass = Ass.toFixed(2);
      this.points[point.name].gp = GP.toFixed(2);
    },
    updatePressureValue: function updatePressureValue(type, value) {
      this.pressureForm[type] = value;
      var isDone = true;

      for (var key in this.pressureForm) {
        if (!this.pressureForm[key] && key != "pressure") {
          isDone = false;
          break;
        }
      }

      console.log(this.pressureForm);

      if (isDone) {
        // Calculation of Mean Artery Pressure:
        var map = parseFloat(this.pressureForm.dbp) + (0.3333 + parseFloat(this.pressureForm.hr) * 0.0012) * (parseFloat(this.pressureForm.sbp) - parseFloat(this.pressureForm.dbp)); // Calculation of Mean Artery Pressure:

        this.pressureForm.pressure = map.toFixed(2);
      }
    },
    onClose: function onClose() {
      var hasError = false;

      if (this.points[this.selectedPoint.name]) {
        for (var key in this.points[this.selectedPoint.name]) {
          if (!this.points[this.selectedPoint.name]['values'][key]) {
            hasError = true;
            break;
          }
        }
      }

      console.log(hasError);
      if (hasError) delete this.points[this.selectedPoint.name];
    },
    isPointCompleted: function isPointCompleted(point) {
      // return Object.keys(this.points).length == 30;
      return true;
    },
    changePivotpoint: function changePivotpoint(event) {
      var oX = event.offsetX;
      var oY = event.offsetY;
      console.log(oX, oY);
      var model = this.$refs['modelViewer'];
      var posandnormal = model.positionAndNormalFromPoint(oX, oY);

      if (posandnormal != null) {
        var position = posandnormal.position;
        var normal = posandnormal.normal;
        var strPosition = position.x + " " + position.y + " " + position.z;
        var cameraTarget = position.x + "m " + position.y + "m " + position.z + "m";
        var strNormal = normal.x + " " + normal.y + " " + normal.z; // var strPosandnormal = JSON.stringify(posandnormal);
        // model.updateHotspot({"name": "hotspot-pivotpoint", "position": strPosition, "normal": strNormal});

        model.cameraTarget = cameraTarget; // document.getElementById("pivotpoint").style.display = "block";
      }

      elsex;
      {
        model.cameraTarget = cameraTarget; // document.getElementById("pivotpoint").style.display = "none";
      }
    },
    showLabel: function showLabel(point) {
      console.log(point);
      alert(point.label);
    },
    getPatientName: function getPatientName(op) {
      return op.name;
    },
    savePoint: function savePoint() {
      var hasError = false;

      for (var key in this.points[this.selectedPoint.name]['values']) {
        console.log(key);

        if (!this.points[this.selectedPoint.name]['values'][key]) {
          if (!this.pointsErrors[this.selectedPoint.name]) {
            this.pointsErrors[this.selectedPoint.name] = {};
          }

          this.pointsErrors[this.selectedPoint.name][key] = "".concat(key, " should not be empty");
          hasError = true;
          break;
        }
      }

      console.log(hasError);

      if (!hasError) {
        this.points[this.selectedPoint.name].done = true;
        this.pointInputPopupActive = false;
        this.pointsKey++;
      }

      this.$forceUpdate(); // document.querySelector(`[data-name=${this.selectedPoint.name}]`).classList.add("done")
    },
    updatePoint: function updatePoint(point, value) {
      this.points[this.selectedPoint.name]['values'][point] = value;

      if (this.pointsErrors[this.selectedPoint.name]) {
        this.pointsErrors[this.selectedPoint.name][point] = "";
      }

      this.$forceUpdate();
    },
    onPointClicked: function onPointClicked(point) {
      this.selectedPoint = point;

      if (!this.points[point.name]) {
        this.points[point.name] = {
          done: false,
          ffr: "",
          wss: "",
          imr: "",
          dss: "",
          ass: "",
          gp: "",
          name: point.name,
          vessel: point.vessel,
          region: point.region,
          values: {
            dp: "",
            ds: "",
            dd: "",
            ll: ""
          }
        };
      }

      this.pointInputPopupActive = true;
    },
    onSubmit: function onSubmit(action) {// const data = await this.form.post("/user/api/niffr_cases");
      // if (data.success) {
      //     Iracode.success(this.__("Niffrcase Created Successfully"));
      //     if (action == "close")
      //         this.$router.push("/user/niffr_cases");
      //     else this.form.reset();
      // }

      return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee7() {
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../User/Resources/js/niffr_cases/PointTable.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!../User/Resources/js/niffr_cases/PointTable.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  props: ['point', 'ctCaseResults'],
  data: function data() {
    return {
      scores: {
        ffr: {
          validationFn: function validationFn(val) {
            if (val >= 0.8) return "Normal > 0.8";
            if (val < 0.8) return "Critical < 0.8";
          }
        },
        imr: {
          validationFn: function validationFn(val) {
            if (val >= 30) return "Critical > 30";
            if (val < 30) return "Normal < 30";
          }
        },
        ass: {
          validationFn: function validationFn(val) {
            if (val >= 70) return "Significant";
            if (val < 70) return "Non-Significant";
          }
        },
        dss: {
          validationFn: function validationFn(val) {
            if (val >= 50) return "Significant";
            if (val < 50) return "Non-Significant";
          }
        },
        wss: {
          validationFn: function validationFn(val) {
            if (val >= 8.0) return "Critical > 8.0";
            if (val < 8.0) return "Normal < 8.0";
          }
        },
        gp: {
          validationFn: function validationFn(val) {
            if (val >= 77) return "Normal >= 77";
            if (val < 77) return "Critical < 77";
          }
        },
        steno: {
          validationFn: function validationFn(val) {
            if (val >= 0.8) return "Non-Significant";
            if (val < 0.8) return "Significant";
          }
        }
      }
    };
  },
  methods: {
    exportAsDocx: function exportAsDocx(name) {
      var _this = this;

      return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
        var point;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.prev = 0;
                console.log(name, _this.ctCaseResults[name], _this.ctCaseResults);
                point = _this.ctCaseResults[name];

                if (point.result_file) {
                  _context.next = 5;
                  break;
                }

                return _context.abrupt("return");

              case 5:
                window.open(_this.url(point.result_file), "_blank");
                _context.next = 10;
                break;

              case 8:
                _context.prev = 8;
                _context.t0 = _context["catch"](0);

              case 10:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, null, [[0, 8]]);
      }))();
    },
    exportAsWord: function exportAsWord(name) {
      var _this2 = this;

      return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2() {
        var point;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.prev = 0;
                console.log(name, _this2.ctCaseResults[name], _this2.ctCaseResults);
                point = _this2.ctCaseResults[name];

                if (point.result_file) {
                  _context2.next = 5;
                  break;
                }

                return _context2.abrupt("return");

              case 5:
                window.open("https://docs.google.com/viewerng/viewer?url=".concat(_this2.url(point.result_file)), "_blank");
                _context2.next = 10;
                break;

              case 8:
                _context2.prev = 8;
                _context2.t0 = _context2["catch"](0);

              case 10:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, null, [[0, 8]]);
      }))();
    },
    renderStatus: function renderStatus(point, type) {
      if (!point) return;
      console.log(point, this.scores, type, "point");
      return this.scores[type] ? this.scores[type].validationFn(point[type]) : null;
    },
    renderFFRClass: function renderFFRClass(point) {
      if (point.ffr > 0.8) {
        return "green";
      } else if (point.ffr >= 0.75 && point.frr < 0.8) {
        return "yellow";
      } else if (point.ffr < 0.75) {
        return "red";
      }

      return "";
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../User/Resources/js/niffr_cases/Points.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!../User/Resources/js/niffr_cases/Points.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _frag__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./frag */ "../User/Resources/js/niffr_cases/frag.js");
/* harmony import */ var _all_points__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./all_points */ "../User/Resources/js/niffr_cases/all_points.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  props: ["pointsForm"],
  directives: {
    frag: _frag__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    return {
      points: _all_points__WEBPACK_IMPORTED_MODULE_1__["default"]
    };
  },
  watch: {
    pointsForm: function pointsForm(newVal, oldVal) {
      console.log(newVal, oldVal);
      this.$forceUpdate();
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!../User/Resources/js/niffr_cases/Create.vue?vue&type=style&index=0&lang=css&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--5-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--5-2!./node_modules/vue-loader/lib??vue-loader-options!../User/Resources/js/niffr_cases/Create.vue?vue&type=style&index=0&lang=css& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../Panel/node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "\n.point-popup .vs-popup{\n      width: 400px !important;\n}\n.validation-error{\n      font-size: 0.8rem;\n      padding-left: 0.5rem;\n}\n.v-nav-menu:fullscreen{\n    display: none !important;\n}\n.loading-wrap{\n    position: absolute;\n    z-index: 999;\n    left: 50%;\n    top: 50%;\n    transform: translate(-50%, -50%);\n}\n.result-popup .vs-popup{\n    min-height:250px\n}\n#mobile-calc{\n        display: none;\n}\n@media(max-width:768px){\n#desktop-calc{\n        display: none;\n}\n#mobile-calc{\n        display: block;\n}\n#mobile-row{\n        width: 115% !important;\n}\n}\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!../User/Resources/js/niffr_cases/PointTable.vue?vue&type=style&index=0&lang=css&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--5-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--5-2!./node_modules/vue-loader/lib??vue-loader-options!../User/Resources/js/niffr_cases/PointTable.vue?vue&type=style&index=0&lang=css& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../Panel/node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "\n.not-data-table{\n    display: none;\n}\n.green{\n background: #16de92;\n color: #fff;\n padding: 1rem;\n}\n.yellow{\n background: yellow;\n padding: 1rem;\n}\n.red{\n background: red;\n color: #fff;\n padding: 1rem;\n}\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!../User/Resources/js/niffr_cases/Points.vue?vue&type=style&index=0&lang=css&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--5-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--5-2!./node_modules/vue-loader/lib??vue-loader-options!../User/Resources/js/niffr_cases/Points.vue?vue&type=style&index=0&lang=css& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../Panel/node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "\n.Hotspot {\n    background: #fff;\n    border-radius: 32px;\n    border: 0;\n    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.25);\n    box-sizing: border-box;\n    cursor: pointer;\n    height: 12px;\n    padding: 5px;\n    position: relative;\n    transition: opacity 0.3s;\n    width: 12px;\n}\n.Hotspot.done{\n        background: red;\n}\n.Hotspot:not([data-visible]) {\n    background: transparent;\n    border: 4px solid #fff;\n    box-shadow: none;\n    height: 12px;\n    pointer-events: none;\n    width: 12px;\n     padding: 2px;\n}\n.Hotspot:focus {\n    border: 4px solid rgb(0, 128, 200);\n    height: 24px;\n    outline: none;\n    width: 24px;\n}\n.Hotspot > * {\n    opacity: 1;\n    transform: translateY(-50%);\n}\n.HotspotAnnotation {\n    background: #fff;\n    border-radius: 4px;\n    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.25);\n    color: rgba(0, 0, 0, 0.8);\n    display: block;\n    font-family: Futura, Helvetica Neue, sans-serif;\n    font-size: 18px;\n    font-weight: 700;\n    left: calc(100% + 1em);\n    max-width: 128px;\n    overflow-wrap: break-word;\n    padding: 0.5em 1em;\n    position: absolute;\n    top: 50%;width: max-content;\n}\n.Hotspot:not([data-visible]) > * {\n    opacity: 0;\n    pointer-events: none;\n    transform: translateY(calc(-50% + 4px));\n    transition: transform 0.3s, opacity 0.3s;\n}\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!../User/Resources/js/niffr_cases/Create.vue?vue&type=style&index=0&lang=css&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--5-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--5-2!./node_modules/vue-loader/lib??vue-loader-options!../User/Resources/js/niffr_cases/Create.vue?vue&type=style&index=0&lang=css& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../Panel/node_modules/css-loader??ref--5-1!../../../../Panel/node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../Panel/node_modules/postcss-loader/src??ref--5-2!../../../../Panel/node_modules/vue-loader/lib??vue-loader-options!./Create.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!../User/Resources/js/niffr_cases/Create.vue?vue&type=style&index=0&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../Panel/node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!../User/Resources/js/niffr_cases/PointTable.vue?vue&type=style&index=0&lang=css&":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--5-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--5-2!./node_modules/vue-loader/lib??vue-loader-options!../User/Resources/js/niffr_cases/PointTable.vue?vue&type=style&index=0&lang=css& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../Panel/node_modules/css-loader??ref--5-1!../../../../Panel/node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../Panel/node_modules/postcss-loader/src??ref--5-2!../../../../Panel/node_modules/vue-loader/lib??vue-loader-options!./PointTable.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!../User/Resources/js/niffr_cases/PointTable.vue?vue&type=style&index=0&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../Panel/node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!../User/Resources/js/niffr_cases/Points.vue?vue&type=style&index=0&lang=css&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--5-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--5-2!./node_modules/vue-loader/lib??vue-loader-options!../User/Resources/js/niffr_cases/Points.vue?vue&type=style&index=0&lang=css& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../Panel/node_modules/css-loader??ref--5-1!../../../../Panel/node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../Panel/node_modules/postcss-loader/src??ref--5-2!../../../../Panel/node_modules/vue-loader/lib??vue-loader-options!./Points.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!../User/Resources/js/niffr_cases/Points.vue?vue&type=style&index=0&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../Panel/node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../User/Resources/js/niffr_cases/Create.vue?vue&type=template&id=b3414e14&":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!../User/Resources/js/niffr_cases/Create.vue?vue&type=template&id=b3414e14& ***!
  \****************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "mb-base niffr-create" },
    [
      _c(
        "vx-card",
        { staticClass: "form" },
        [
          _c("h5", { staticClass: "mb-4", staticStyle: { color: "#494aa6" } }, [
            _vm._v("Patient Information")
          ]),
          _vm._v(" "),
          _c(
            "form",
            [
              _c(
                "vs-row",
                {
                  staticClass: "mb-6 m-0",
                  attrs: { "vs-type": "flex", "vs-w": "12" }
                },
                [
                  _c(
                    "vs-col",
                    {
                      attrs: {
                        "vs-type": "flex",
                        "vs-align": "center",
                        "vs-lg": "3",
                        "vs-sm": "6",
                        "vs-xs": "12"
                      }
                    },
                    [
                      _c("div", { staticClass: "flex mr-5 text-left" }, [
                        _c("span", [_vm._v(_vm._s(_vm.__("Name")))]),
                        _vm._v(" "),
                        _c("span", { staticClass: "ml-1 text-red" }, [
                          _vm._v("*")
                        ])
                      ]),
                      _vm._v(" "),
                      _c(_vm.inputs.name.type, {
                        tag: "component",
                        staticClass: "w-full",
                        attrs: {
                          danger: _vm.hasValidationError("name"),
                          "danger-text": _vm.validationError("name"),
                          name: "name",
                          type: "text"
                        },
                        model: {
                          value: _vm.form.name,
                          callback: function($$v) {
                            _vm.$set(_vm.form, "name", $$v)
                          },
                          expression: "form.name"
                        }
                      })
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      attrs: {
                        "vs-type": "flex",
                        "vs-align": "center",
                        "vs-lg": "3",
                        "vs-sm": "6",
                        "vs-xs": "12"
                      }
                    },
                    [
                      _c("div", { staticClass: "flex mr-5 text-left" }, [
                        _c("span", [_vm._v(_vm._s(_vm.__("Hospital")))]),
                        _vm._v(" "),
                        _c("span", { staticClass: "ml-1 text-red" }, [
                          _vm._v("*")
                        ])
                      ]),
                      _vm._v(" "),
                      _c(_vm.inputs.hospital.type, {
                        tag: "component",
                        staticClass: "w-full",
                        attrs: {
                          danger: _vm.hasValidationError("hospital"),
                          "danger-text": _vm.validationError("hospital"),
                          name: "hospital",
                          type: "text"
                        },
                        model: {
                          value: _vm.form.hospital,
                          callback: function($$v) {
                            _vm.$set(_vm.form, "hospital", $$v)
                          },
                          expression: "form.hospital"
                        }
                      })
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      attrs: {
                        "vs-type": "flex",
                        "vs-align": "center",
                        "vs-lg": "2",
                        "vs-sm": "6",
                        "vs-xs": "6"
                      }
                    },
                    [
                      _c("div", { staticClass: "flex mr-5 text-left" }, [
                        _c("span", [_vm._v(_vm._s(_vm.__("Age")))]),
                        _vm._v(" "),
                        _c("span", { staticClass: "ml-1 text-red" }, [
                          _vm._v("*")
                        ])
                      ]),
                      _vm._v(" "),
                      _c(_vm.inputs.age.type, {
                        tag: "component",
                        staticClass: "w-full",
                        attrs: {
                          danger: _vm.hasValidationError("age"),
                          "danger-text": _vm.validationError("age"),
                          name: "age",
                          type: "number"
                        },
                        model: {
                          value: _vm.form.age,
                          callback: function($$v) {
                            _vm.$set(_vm.form, "age", $$v)
                          },
                          expression: "form.age"
                        }
                      })
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      attrs: {
                        "vs-type": "flex",
                        "vs-align": "center",
                        "vs-lg": "2",
                        "vs-sm": "6",
                        "vs-xs": "6"
                      }
                    },
                    [
                      _c("div", { staticClass: "flex mr-5 text-left " }, [
                        _c("span", [_vm._v(_vm._s(_vm.__("Physician")))]),
                        _vm._v(" "),
                        _c("span", { staticClass: "ml-1 text-red" }, [
                          _vm._v("*")
                        ])
                      ]),
                      _vm._v(" "),
                      _c(_vm.inputs.physician.type, {
                        tag: "component",
                        staticClass: "w-full",
                        attrs: {
                          danger: _vm.hasValidationError("physician"),
                          "danger-text": _vm.validationError("physician"),
                          name: "physician",
                          type: "text"
                        },
                        model: {
                          value: _vm.form.physician,
                          callback: function($$v) {
                            _vm.$set(_vm.form, "physician", $$v)
                          },
                          expression: "form.physician"
                        }
                      })
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-col",
                    {
                      staticStyle: {
                        "flex-direction": "column",
                        "justify-content": "center"
                      },
                      attrs: {
                        "vs-type": "flex",
                        "vs-align": "center",
                        "vs-lg": "2",
                        "vs-sm": "6",
                        "vs-xs": "12"
                      }
                    },
                    [
                      _c(
                        "div",
                        [
                          _c(
                            "vs-radio",
                            {
                              attrs: { "vs-name": "sex", "vs-value": "1" },
                              model: {
                                value: _vm.form.sex,
                                callback: function($$v) {
                                  _vm.$set(_vm.form, "sex", $$v)
                                },
                                expression: "form.sex"
                              }
                            },
                            [_vm._v("Male")]
                          ),
                          _vm._v(" "),
                          _c(
                            "vs-radio",
                            {
                              staticClass: "ml-4",
                              attrs: { "vs-name": "sex", "vs-value": "0" },
                              model: {
                                value: _vm.form.sex,
                                callback: function($$v) {
                                  _vm.$set(_vm.form, "sex", $$v)
                                },
                                expression: "form.sex"
                              }
                            },
                            [_vm._v("Female")]
                          )
                        ],
                        1
                      )
                    ]
                  )
                ],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "vs-row",
            {
              staticClass: "my-6",
              attrs: { id: "mobile-row", "vs-type": "flex", "vs-w": "12" }
            },
            [
              _c(
                "vs-col",
                { attrs: { "vs-lg": "8", "vs-sm": "12", "vs-xs": "12" } },
                [
                  _c(
                    "h5",
                    { staticClass: "mb-4", staticStyle: { color: "#494aa6" } },
                    [_vm._v("Select Stenosis Spot of 3D Coronary")]
                  ),
                  _vm._v(" "),
                  _c(
                    "model-viewer",
                    {
                      ref: "modelViewer",
                      staticStyle: {
                        width: "100%",
                        height: "500px",
                        background: "rgb(180 169 169)"
                      },
                      attrs: {
                        id: "model",
                        "camera-change": "onCameraChange",
                        src: "/glb35.glb",
                        alt: "A 3D model of an astronaut",
                        "camera-controls": ""
                      }
                    },
                    [
                      _vm.showPoints
                        ? _c("points", {
                            key: _vm.pointsKey,
                            attrs: { pointsForm: _vm.points },
                            on: { pointClicked: _vm.onPointClicked }
                          })
                        : _vm._e()
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-button",
                    {
                      staticClass: "mt-4",
                      staticStyle: { width: "100%" },
                      attrs: {
                        id: "desktop-calc",
                        color: "success",
                        size: "large",
                        type: "filled"
                      },
                      on: { click: _vm.saveNiffr }
                    },
                    [_vm._v("Calculate")]
                  )
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "vs-col",
                { attrs: { "vs-lg": "4", "vs-sm": "12", "vs-xs": "12" } },
                [
                  _c(
                    "form",
                    { attrs: { action: "" } },
                    [
                      _c("div", [
                        _c(
                          "div",
                          {
                            staticClass:
                              "flex justify-between items-center my-8"
                          },
                          [
                            _c(
                              "h6",
                              {
                                staticStyle: {
                                  color: "#494aa6",
                                  "font-size": "1.2rem"
                                },
                                attrs: { for: "" }
                              },
                              [
                                _vm._v(
                                  _vm._s(
                                    _vm.__("Angiography Device Frame Number")
                                  )
                                )
                              ]
                            )
                          ]
                        ),
                        _vm._v(" "),
                        _c(
                          "div",
                          { staticClass: "flex" },
                          [
                            _c(
                              "vs-radio",
                              {
                                staticStyle: { margin: "0 0.5rem" },
                                attrs: {
                                  "vs-name": "radios1",
                                  "vs-value": 7.5
                                },
                                model: {
                                  value: _vm.frame_number,
                                  callback: function($$v) {
                                    _vm.frame_number = $$v
                                  },
                                  expression: "frame_number"
                                }
                              },
                              [_vm._v("7.5 Frame/s")]
                            ),
                            _vm._v(" "),
                            _c(
                              "vs-radio",
                              {
                                staticStyle: { margin: "0 0.5rem" },
                                attrs: { "vs-name": "radios1", "vs-value": 15 },
                                model: {
                                  value: _vm.frame_number,
                                  callback: function($$v) {
                                    _vm.frame_number = $$v
                                  },
                                  expression: "frame_number"
                                }
                              },
                              [_vm._v("15 Frame/s")]
                            )
                          ],
                          1
                        )
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "my-8" }, [
                        _c(
                          "h6",
                          {
                            staticClass: "mb-4 ",
                            staticStyle: {
                              color: "#494aa6",
                              "font-size": "1.2rem"
                            }
                          },
                          [_vm._v("TIMI Frame Count:")]
                        )
                      ]),
                      _vm._v(" "),
                      _c(
                        "vs-row",
                        {
                          staticClass: "pt-1",
                          staticStyle: { display: "flex" }
                        },
                        [
                          _c(
                            "vs-col",
                            {
                              staticClass: "flex justify-between items-center",
                              attrs: { "vs-lg": "2" }
                            },
                            [
                              _c(
                                "h6",
                                { staticClass: "mr-4", attrs: { for: "" } },
                                [_vm._v(_vm._s(_vm.__("TFC")))]
                              )
                            ]
                          ),
                          _vm._v(" "),
                          _c(
                            "vs-col",
                            { staticClass: "TFC", attrs: { "vs-lg": "4" } },
                            [
                              _c("vs-input", {
                                staticClass: "my-2 w-full",
                                attrs: { type: "number" },
                                model: {
                                  value: _vm.tfc,
                                  callback: function($$v) {
                                    _vm.tfc = $$v
                                  },
                                  expression: "tfc"
                                }
                              })
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "vs-col",
                            {
                              staticClass: "flex align-items-center",
                              attrs: { "vs-lg": "6" }
                            },
                            [_c("p", [_vm._v("Frame ")])]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c("div", { staticClass: "my-8" }, [
                        _c(
                          "h6",
                          {
                            staticClass: "mb-4 my-4",
                            staticStyle: {
                              color: "#494aa6",
                              "font-size": "1.2rem"
                            }
                          },
                          [_vm._v("Mean Artery Pressure:")]
                        )
                      ]),
                      _vm._v(" "),
                      _c(
                        "vs-row",
                        {
                          staticClass: "mt-2",
                          staticStyle: {
                            display: "flex",
                            "align-items": "center"
                          }
                        },
                        [
                          _c(
                            "h6",
                            {
                              staticClass: "mx-2",
                              staticStyle: { width: "10%" },
                              attrs: { for: "" }
                            },
                            [_vm._v(_vm._s(_vm.__("DBP")))]
                          ),
                          _vm._v(" "),
                          _c("vs-input", {
                            staticClass: "my-2",
                            staticStyle: { width: "25%" },
                            attrs: {
                              type: "number",
                              value: _vm.pressureForm.dbp
                            },
                            on: {
                              input: function(value) {
                                return _vm.updatePressureValue("dbp", value)
                              }
                            }
                          }),
                          _vm._v(" "),
                          _c(
                            "p",
                            {
                              staticClass: "mx-2",
                              staticStyle: { "font-size": "12px", width: "50%" }
                            },
                            [_vm._v("mmHg, Diastolic Pressure  ")]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "vs-row",
                        {
                          staticStyle: {
                            display: "flex",
                            "align-items": "center"
                          }
                        },
                        [
                          _c(
                            "h6",
                            {
                              staticClass: "mx-2",
                              staticStyle: { width: "10%" },
                              attrs: { for: "" }
                            },
                            [_vm._v(_vm._s(_vm.__("SBP")))]
                          ),
                          _vm._v(" "),
                          _c("vs-input", {
                            staticClass: "my-2 ",
                            staticStyle: { width: "25%" },
                            attrs: {
                              type: "number",
                              value: _vm.pressureForm.sbp
                            },
                            on: {
                              input: function(value) {
                                return _vm.updatePressureValue("sbp", value)
                              }
                            }
                          }),
                          _vm._v(" "),
                          _c(
                            "p",
                            {
                              staticClass: "mx-2",
                              staticStyle: { "font-size": "12px", width: "50%" }
                            },
                            [_vm._v("mmHg, Systolic Pressure  ")]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "vs-row",
                        {
                          staticStyle: {
                            display: "flex",
                            "align-items": "center"
                          }
                        },
                        [
                          _c(
                            "h6",
                            {
                              staticClass: "mx-2",
                              staticStyle: { width: "10%" },
                              attrs: { for: "" }
                            },
                            [_vm._v(_vm._s(_vm.__("HR")))]
                          ),
                          _vm._v(" "),
                          _c("vs-input", {
                            staticClass: "my-2 ",
                            staticStyle: { width: "25%" },
                            attrs: {
                              type: "number",
                              value: _vm.pressureForm.hr
                            },
                            on: {
                              input: function(value) {
                                return _vm.updatePressureValue("hr", value)
                              }
                            }
                          }),
                          _vm._v(" "),
                          _c(
                            "p",
                            {
                              staticClass: "mx-2",
                              staticStyle: { "font-size": "12px", width: "50%" }
                            },
                            [_vm._v("beat/s Heart Rate  ")]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "vs-row",
                        {
                          staticStyle: {
                            display: "flex",
                            "align-items": "center"
                          }
                        },
                        [
                          _c(
                            "h6",
                            {
                              staticClass: "mx-2",
                              staticStyle: { width: "10%" },
                              attrs: { for: "" }
                            },
                            [_vm._v(_vm._s(_vm.__("MAP")))]
                          ),
                          _vm._v(" "),
                          _c("vs-input", {
                            staticClass: "my-2 ",
                            staticStyle: { width: "25%" },
                            attrs: {
                              type: "number",
                              readonly: "",
                              value: _vm.pressureForm.pressure
                            }
                          }),
                          _vm._v(" "),
                          _c(
                            "p",
                            {
                              staticClass: "mx-2",
                              staticStyle: { "font-size": "12px", width: "50%" }
                            },
                            [_vm._v("mmHg,  ")]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "h6",
                        {
                          staticClass: "mb-4 my-4",
                          staticStyle: {
                            color: "#494aa6",
                            "font-size": "1.2rem"
                          }
                        },
                        [_vm._v("Distal Length:")]
                      ),
                      _vm._v(" "),
                      _c(
                        "vs-row",
                        {
                          staticStyle: {
                            display: "flex",
                            "align-items": "center"
                          }
                        },
                        [
                          _c(
                            "h6",
                            {
                              staticClass: "mx-2",
                              staticStyle: { width: "10%" },
                              attrs: { for: "" }
                            },
                            [_vm._v(_vm._s(_vm.__("DL")))]
                          ),
                          _vm._v(" "),
                          _c("vs-input", {
                            staticClass: "my-2 ",
                            staticStyle: { width: "25%" },
                            attrs: { type: "number" },
                            model: {
                              value: _vm.ld,
                              callback: function($$v) {
                                _vm.ld = $$v
                              },
                              expression: "ld"
                            }
                          }),
                          _vm._v(" "),
                          _c(
                            "p",
                            {
                              staticClass: "mx-2",
                              staticStyle: { "font-size": "12px", width: "50%" }
                            },
                            [_vm._v("mm Distal Length ")]
                          )
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-button",
                    {
                      staticClass: "mt-4",
                      staticStyle: { width: "100%" },
                      attrs: {
                        id: "mobile-calc",
                        color: "success",
                        size: "large",
                        type: "filled"
                      },
                      on: { click: _vm.saveNiffr }
                    },
                    [_vm._v("Calculate")]
                  )
                ],
                1
              )
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "vs-popup",
        {
          staticClass: "holamundo",
          attrs: {
            title: "IMPORTANT INFORMATION",
            active: _vm.noticePopupOpen
          },
          on: {
            "update:active": function($event) {
              _vm.noticePopupOpen = $event
            }
          }
        },
        [
          _c("img", {
            staticStyle: { "max-width": "100%" },
            attrs: { src: _vm.url("assets/img/niffr.png"), alt: "" }
          }),
          _vm._v(" "),
          _c("h4", { staticClass: "text-center my-4" }, [
            _vm._v("\n              IMPORTANT INFORMATION\n          ")
          ]),
          _vm._v(" "),
          _c("p", [
            _vm._v(
              "\n              The Functional SYNTAX Score (based on non-invasive fractional flow reserved (NiFFR)) is a tool developed in connection with the SYNTAX Trial, a trial comparing PCI and Cardiac Surgery in complex, high-risk LM and/or 3VD patients. By combining anatomic and clinical prognostic variables, the Functional SYNTAX score (based on (NiFFR)) creates accurate mortality predictions to guide the choice between PCI and CABG for patients with multivessel coronary disease. The Functional SYNTAX score calculator provides the doctor with an individual, patient-oriented treatment recommendation based on the mortality risk. This tool was validated in different registries and randomized trials. It has also been the basis for the ongoing SYNTAX II trial and is currently being tested on a non-invasive MSCT approach in the SYNTAX III REVOLUTION study.\n          "
            )
          ]),
          _vm._v(" "),
          _c(
            "vs-checkbox",
            {
              staticClass: "my-4",
              model: {
                value: _vm.niffer_tos,
                callback: function($$v) {
                  _vm.niffer_tos = $$v
                },
                expression: "niffer_tos"
              }
            },
            [_vm._v("Yes, I have fully read the Important Information above.")]
          ),
          _vm._v(" "),
          _c(
            "vs-button",
            {
              attrs: { color: "success", type: "filled" },
              on: { click: _vm.submitTos }
            },
            [_vm._v("Save")]
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "vs-popup",
        {
          staticClass: "holamundo point-popup",
          attrs: {
            title: _vm.selectedPoint ? _vm.selectedPoint.label : "",
            active: _vm.pointInputPopupActive
          },
          on: {
            close: _vm.onClose,
            "update:active": function($event) {
              _vm.pointInputPopupActive = $event
            }
          }
        },
        [
          _vm.selectedPoint.name && _vm.points[_vm.selectedPoint.name]
            ? _c(
                "form",
                { attrs: { action: "" } },
                [
                  _c(
                    "vs-row",
                    [
                      _c(
                        "vs-col",
                        {
                          staticClass: "flex align-items-center",
                          attrs: { "vs-lg": "2" }
                        },
                        [
                          _c("p", { staticStyle: { "font-weight": "bold" } }, [
                            _vm._v("Dp(mm)")
                          ])
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "vs-col",
                        { attrs: { "vs-lg": "5" } },
                        [
                          _c("vs-input", {
                            staticClass: "my-2",
                            staticStyle: { width: "100%" },
                            attrs: {
                              type: "number",
                              value:
                                _vm.points[_vm.selectedPoint.name].values.dp
                            },
                            on: {
                              input: function(value) {
                                return _vm.updatePoint("dp", value)
                              }
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "vs-col",
                        {
                          staticClass: "flex align-items-center",
                          attrs: { "vs-lg": "5" }
                        },
                        [
                          _c("p", { staticStyle: { "font-weight": "bold" } }, [
                            _vm._v("Proximal Diameter ")
                          ])
                        ]
                      ),
                      _vm._v(" "),
                      _vm.pointsErrors[_vm.selectedPoint.name] &&
                      _vm.pointsErrors[_vm.selectedPoint.name]["dp"]
                        ? _c("strong", { staticClass: "validation-error" }, [
                            _vm._v(
                              "\n                        " +
                                _vm._s(
                                  _vm.pointsErrors[_vm.selectedPoint.name]["dp"]
                                ) +
                                "\n                    "
                            )
                          ])
                        : _vm._e()
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-row",
                    [
                      _c(
                        "vs-col",
                        {
                          staticClass: "flex align-items-center",
                          attrs: { "vs-lg": "2" }
                        },
                        [
                          _c("p", { staticStyle: { "font-weight": "bold" } }, [
                            _vm._v("Ds(mm)")
                          ])
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "vs-col",
                        { attrs: { "vs-lg": "5" } },
                        [
                          _c("vs-input", {
                            staticClass: "my-2",
                            staticStyle: { width: "100%" },
                            attrs: {
                              type: "number",
                              value:
                                _vm.points[_vm.selectedPoint.name].values.ds
                            },
                            on: {
                              input: function(value) {
                                return _vm.updatePoint("ds", value)
                              }
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "vs-col",
                        {
                          staticClass: "flex align-items-center",
                          attrs: { "vs-lg": "5" }
                        },
                        [
                          _c("p", { staticStyle: { "font-weight": "bold" } }, [
                            _vm._v("Diameter Stenosis  ")
                          ])
                        ]
                      ),
                      _vm._v(" "),
                      _vm.pointsErrors[_vm.selectedPoint.name] &&
                      _vm.pointsErrors[_vm.selectedPoint.name]["ds"]
                        ? _c("strong", { staticClass: "validation-error" }, [
                            _vm._v(
                              "\n                        " +
                                _vm._s(
                                  _vm.pointsErrors[_vm.selectedPoint.name]["ds"]
                                ) +
                                "\n                    "
                            )
                          ])
                        : _vm._e()
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-row",
                    [
                      _c(
                        "vs-col",
                        {
                          staticClass: "flex align-items-center",
                          attrs: { "vs-lg": "2" }
                        },
                        [
                          _c("p", { staticStyle: { "font-weight": "bold" } }, [
                            _vm._v("Dd(mm)")
                          ])
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "vs-col",
                        { attrs: { "vs-lg": "5" } },
                        [
                          _c("vs-input", {
                            staticClass: "my-2",
                            staticStyle: { width: "100%" },
                            attrs: {
                              type: "number",
                              value:
                                _vm.points[_vm.selectedPoint.name].values.dd
                            },
                            on: {
                              input: function(value) {
                                return _vm.updatePoint("dd", value)
                              }
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "vs-col",
                        {
                          staticClass: "flex align-items-center",
                          attrs: { "vs-lg": "5" }
                        },
                        [
                          _c("p", { staticStyle: { "font-weight": "bold" } }, [
                            _vm._v("Distal Diameter  ")
                          ])
                        ]
                      ),
                      _vm._v(" "),
                      _vm.pointsErrors[_vm.selectedPoint.name] &&
                      _vm.pointsErrors[_vm.selectedPoint.name]["dd"]
                        ? _c("strong", { staticClass: "validation-error" }, [
                            _vm._v(
                              "\n                        " +
                                _vm._s(
                                  _vm.pointsErrors[_vm.selectedPoint.name]["dd"]
                                ) +
                                "\n                    "
                            )
                          ])
                        : _vm._e()
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-row",
                    [
                      _c(
                        "vs-col",
                        {
                          staticClass: "flex align-items-center",
                          attrs: { "vs-lg": "2" }
                        },
                        [
                          _c("p", { staticStyle: { "font-weight": "bold" } }, [
                            _vm._v("LL(mm)")
                          ])
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "vs-col",
                        { attrs: { "vs-lg": "5" } },
                        [
                          _c("vs-input", {
                            staticClass: "my-2",
                            staticStyle: { width: "100%" },
                            attrs: {
                              type: "number",
                              value:
                                _vm.points[_vm.selectedPoint.name].values.ll
                            },
                            on: {
                              input: function(value) {
                                return _vm.updatePoint("ll", value)
                              }
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "vs-col",
                        {
                          staticClass: "flex align-items-center",
                          attrs: { "vs-lg": "5" }
                        },
                        [
                          _c("p", { staticStyle: { "font-weight": "bold" } }, [
                            _vm._v("Lesion Length  ")
                          ])
                        ]
                      ),
                      _vm._v(" "),
                      _vm.pointsErrors[_vm.selectedPoint.name] &&
                      _vm.pointsErrors[_vm.selectedPoint.name]["ll"]
                        ? _c("strong", { staticClass: "validation-error" }, [
                            _vm._v(
                              "\n                        " +
                                _vm._s(
                                  _vm.pointsErrors[_vm.selectedPoint.name]["ll"]
                                ) +
                                "\n                    "
                            )
                          ])
                        : _vm._e()
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "vs-button",
                    {
                      staticStyle: { width: "100%", "margin-top": "1rem" },
                      attrs: { color: "success", type: "filled" },
                      on: { click: _vm.savePoint }
                    },
                    [_vm._v("Save")]
                  )
                ],
                1
              )
            : _vm._e()
        ]
      ),
      _vm._v(" "),
      _c(
        "vs-popup",
        {
          staticClass: "holamundo result-popup",
          attrs: { title: "Result", active: _vm.resultPopupActive },
          on: {
            "update:active": function($event) {
              _vm.resultPopupActive = $event
            }
          }
        },
        [
          _vm.isLoading
            ? _c("div", { staticClass: "loading-wrap" }, [
                _c("img", {
                  staticStyle: { width: "150px" },
                  attrs: { src: "/images/loader.gif", alt: "" }
                })
              ])
            : _c("div", [
                Object.keys(_vm.points).length > 0 && _vm.resultPopupActive
                  ? _c(
                      "div",
                      _vm._l(_vm.points, function(point, key) {
                        return _c("div", { key: key }, [
                          point.done
                            ? _c(
                                "div",
                                [
                                  _c("h4", [
                                    _vm._v(_vm._s(point.name.replace("_", " ")))
                                  ]),
                                  _vm._v(" "),
                                  _c("point-table", {
                                    attrs: {
                                      ctCaseResults: _vm.ctCaseResults,
                                      point: point
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("hr")
                                ],
                                1
                              )
                            : _vm._e()
                        ])
                      }),
                      0
                    )
                  : _c("div", [
                      _c("h4", [_vm._v("You did not select any vessel")])
                    ])
              ])
        ]
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../User/Resources/js/niffr_cases/PointTable.vue?vue&type=template&id=47aac618&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!../User/Resources/js/niffr_cases/PointTable.vue?vue&type=template&id=47aac618& ***!
  \********************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "vs-table",
        { attrs: { noDataText: "" } },
        [
          _c("template", { slot: "header" }, [_c("h3")]),
          _vm._v(" "),
          _c(
            "template",
            { slot: "thead" },
            [
              _c("vs-th", [
                _vm._v("\n            Hemodynamic Parameters\n            ")
              ]),
              _vm._v(" "),
              _c("vs-th", [_vm._v("\n            Result\n            ")]),
              _vm._v(" "),
              _c("vs-th", [_vm._v("\n            Status\n            ")])
            ],
            1
          ),
          _vm._v(" "),
          [
            _c(
              "vs-tr",
              [
                _c("vs-td", [
                  _c("strong", [_vm._v(" Fractional Flow Reserved (FFR)")])
                ]),
                _vm._v(" "),
                _c("vs-td", [
                  _c("strong", [_vm._v(" " + _vm._s(_vm.point.ffr))])
                ]),
                _vm._v(" "),
                _c("vs-td", [
                  _c("strong", [
                    _vm._v(" " + _vm._s(_vm.renderStatus(_vm.point, "ffr")))
                  ])
                ])
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "vs-tr",
              [
                _c("vs-td", [_c("strong", [_vm._v(" Area Stenosis (% AS)")])]),
                _vm._v(" "),
                _c("vs-td", [
                  _c("strong", [_vm._v(" " + _vm._s(_vm.point.ass))])
                ]),
                _vm._v(" "),
                _c("vs-td", [
                  _c("strong", [
                    _vm._v(" " + _vm._s(_vm.renderStatus(_vm.point, "ass")))
                  ])
                ])
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "vs-tr",
              [
                _c("vs-td", [
                  _c("strong", [_vm._v(" Diameter Stenosis (% DS)")])
                ]),
                _vm._v(" "),
                _c("vs-td", [
                  _c("strong", [_vm._v(" " + _vm._s(_vm.point.dss))])
                ]),
                _vm._v(" "),
                _c("vs-td", [
                  _c("strong", [
                    _vm._v(" " + _vm._s(_vm.renderStatus(_vm.point, "dss")))
                  ])
                ])
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "vs-tr",
              [
                _c("vs-td", [
                  _c("strong", [_vm._v(" Wall Shear Stress (WSS)")])
                ]),
                _vm._v(" "),
                _c("vs-td", [
                  _c("strong", [_vm._v(" " + _vm._s(_vm.point.wss))])
                ]),
                _vm._v(" "),
                _c("vs-td", [
                  _c("strong", [
                    _vm._v(" " + _vm._s(_vm.renderStatus(_vm.point, "wss")))
                  ])
                ])
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "vs-tr",
              [
                _c("vs-td", [
                  _c("strong", [_vm._v(" Microvascular Resistance (IMR)")])
                ]),
                _vm._v(" "),
                _c("vs-td", [
                  _c("strong", [_vm._v(" " + _vm._s(_vm.point.imr))])
                ]),
                _vm._v(" "),
                _c("vs-td", [
                  _c("strong", [
                    _vm._v(" " + _vm._s(_vm.renderStatus(_vm.point, "imr")))
                  ])
                ])
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "vs-tr",
              [
                _c("vs-td", [
                  _c("strong", [_vm._v(" Gradient Of Pressure (Del.P)")])
                ]),
                _vm._v(" "),
                _c("vs-td", [
                  _c("strong", [_vm._v(" " + _vm._s(_vm.point.gp))])
                ]),
                _vm._v(" "),
                _c("vs-td", [
                  _c("strong", [
                    _vm._v(" " + _vm._s(_vm.renderStatus(_vm.point, "gp")))
                  ])
                ])
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "vs-tr",
              [
                _c("vs-td", [_c("strong", [_vm._v(" Stenosis Condition")])]),
                _vm._v(" "),
                _c("vs-td", { attrs: { colspan: "2" } }, [
                  _vm._v(
                    "\n                    " +
                      _vm._s(_vm.renderStatus(_vm.point, "steno")) +
                      "\n                "
                  )
                ])
              ],
              1
            )
          ]
        ],
        2
      ),
      _vm._v(" "),
      _c(
        "vs-row",
        { staticClass: "mt-3 flex justify-between" },
        [
          _c("vs-col", { attrs: { "vs-lg": "3" } }, [
            _c(
              "div",
              {
                class: _vm.renderFFRClass(_vm.point),
                staticStyle: { width: "100%" }
              },
              [
                _c("span", { staticStyle: { "font-size": "1.2rem" } }, [
                  _vm._v("FFR:")
                ]),
                _vm._v(" "),
                _c("strong", { staticStyle: { "font-size": "1.2rem" } }, [
                  _vm._v(_vm._s(_vm.point.ffr))
                ])
              ]
            )
          ]),
          _vm._v(" "),
          _c("vs-col", { attrs: { "vs-lg": "9" } }, [
            _c(
              "div",
              {
                class: _vm.renderFFRClass(_vm.point),
                staticStyle: { width: "107%" }
              },
              [
                _c("span", { staticStyle: { "font-size": "1.2rem" } }, [
                  _vm._v("Status:")
                ]),
                _vm._v(" "),
                _c("strong", { staticStyle: { "font-size": "1.2rem" } }, [
                  _vm._v(_vm._s(_vm.renderStatus(_vm.point, "ffr")))
                ])
              ]
            )
          ])
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "vs-button",
        {
          staticClass: "mt-3",
          staticStyle: { width: "100%" },
          attrs: { color: "success", type: "filled" },
          on: {
            click: function() {
              return _vm.exportAsDocx(_vm.point.name)
            }
          }
        },
        [_vm._v("Export as Word")]
      ),
      _vm._v(" "),
      _c(
        "vs-button",
        {
          staticClass: "mt-3",
          staticStyle: { width: "100%" },
          attrs: { color: "success", type: "filled" },
          on: {
            click: function() {
              return _vm.exportAsWord(_vm.point.name)
            }
          }
        },
        [_vm._v("Export as PDF")]
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../User/Resources/js/niffr_cases/Points.vue?vue&type=template&id=bd706d46&":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!../User/Resources/js/niffr_cases/Points.vue?vue&type=template&id=bd706d46& ***!
  \****************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { directives: [{ name: "frag", rawName: "v-frag" }] }, [
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done: _vm.pointsForm["LM_OSTIAL"] && _vm.pointsForm["LM_OSTIAL"].done
      },
      attrs: {
        slot: "hotspot-4",
        "data-name": "LM_OSTIAL",
        "data-position":
          "0.29230763221275413m 0.1632841509086988m 0.07139593915393697m",
        "data-normal":
          "0.9711708855156178m 0.1541834634979456m -0.1818091601393846m",
        "data-visibility-attribute": "visible",
        "data-label": "LM OSTIAL"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["LM_OSTIAL"])
        }
      },
      slot: "hotspot-4"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done: _vm.pointsForm["LM_DISTAL"] && _vm.pointsForm["LM_DISTAL"].done
      },
      attrs: {
        slot: "hotspot-5",
        "data-name": "LM_DISTAL",
        "data-position":
          "0.30792571808573277m 0.14507550974047634m 0.11883588237895723m",
        "data-normal":
          "0.9366079762833974m 0.3500385176733865m 0.01544457533690471m",
        "data-visibility-attribute": "visible",
        "data-label": "LM DISTAL"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["LM_DISTAL"])
        }
      },
      slot: "hotspot-5"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done: _vm.pointsForm["LAD_OSTIAL"] && _vm.pointsForm["LAD_OSTIAL"].done
      },
      attrs: {
        slot: "hotspot-8",
        "data-name": "LAD_OSTIAL",
        "data-position":
          "0.32909152865197877m 0.11633500365039724m 0.15194304425170868m",
        "data-normal":
          "0.8437969938204799m 0.5170677952555434m -0.14369247833165313m",
        "data-visibility-attribute": "visible",
        "data-label": "LAD OSTIAL"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["LAD_OSTIAL"])
        }
      },
      slot: "hotspot-8"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done:
          _vm.pointsForm["LAD_PROXIMAL"] && _vm.pointsForm["LAD_PROXIMAL"].done
      },
      attrs: {
        slot: "hotspot-9",
        "data-name": "LAD_PROXIMAL",
        "data-position":
          "0.3695550475443147m 0.06367153351988768m 0.2014584473360373m",
        "data-normal":
          "0.870695993439877m 0.40979707620729017m -0.27194639791639463m",
        "data-visibility-attribute": "visible",
        "data-label": "LAD PROXIMAL"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["LAD_PROXIMAL"])
        }
      },
      slot: "hotspot-9"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done:
          _vm.pointsForm["LAD_MID_PART"] && _vm.pointsForm["LAD_MID_PART"].done
      },
      attrs: {
        slot: "hotspot-10",
        "data-name": "LAD_MID_PART",
        "data-position":
          "0.4098292433175047m -0.016395445390416152m 0.4453843592941024m",
        "data-normal":
          "0.980783660387004m 0.18217773904102075m 0.06981892949460027m",
        "data-visibility-attribute": "visible",
        "data-label": "LAD MID PART"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["LAD_MID_PART"])
        }
      },
      slot: "hotspot-10"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done: _vm.pointsForm["LAD_DISTAL"] && _vm.pointsForm["LAD_DISTAL"].done
      },
      attrs: {
        slot: "hotspot-11",
        "data-name": "LAD_DISTAL",
        "data-position":
          "0.35698283090534394m -0.17323511690518623m 0.6998857082341631m",
        "data-normal":
          "0.8969156050795585m 0.14854908209630763m 0.41650398266176764m",
        "data-visibility-attribute": "visible",
        "data-label": "LAD DISTAL"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["LAD_DISTAL"])
        }
      },
      slot: "hotspot-11"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done: _vm.pointsForm["DIAGONAL_2"] && _vm.pointsForm["DIAGONAL_2"].done
      },
      attrs: {
        slot: "hotspot-12",
        "data-name": "DIAGONAL_2",
        "data-position":
          "0.4218183504015556m -0.09182736981690182m 0.5592602808437199m",
        "data-normal":
          "0.35812018093919856m 0.22452136925590319m 0.9062781530807913m",
        "data-visibility-attribute": "visible",
        "data-label": "DIAGONAL 2"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["DIAGONAL_2"])
        }
      },
      slot: "hotspot-12"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done: _vm.pointsForm["Dig_OSTIAL"] && _vm.pointsForm["Dig_OSTIAL"].done
      },
      attrs: {
        slot: "hotspot-13",
        "data-name": "Dig_OSTIAL",
        "data-position":
          "0.4220019120071351m -0.01878174528064748m 0.36158172553046986m",
        "data-normal":
          "0.8707969366931463m 0.36141126634408055m 0.3333085531536816m",
        "data-visibility-attribute": "visible",
        "data-label": "Dig OSTIAL"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["Dig_OSTIAL"])
        }
      },
      slot: "hotspot-13"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done:
          _vm.pointsForm["Dig_PROXIMAL"] && _vm.pointsForm["Dig_PROXIMAL"].done
      },
      attrs: {
        slot: "hotspot-14",
        "data-name": "Dig_PROXIMAL",
        "data-position":
          "0.43715181970072625m -0.06426058413413524m 0.40188219780230117m",
        "data-normal":
          "0.9974440033186937m 0.0528642805484142m -0.04807107327360586m",
        "data-visibility-attribute": "visible",
        "data-label": "Dig PROXIMAL"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["Dig_PROXIMAL"])
        }
      },
      slot: "hotspot-14"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done: _vm.pointsForm["LCX_OSTIAL"] && _vm.pointsForm["LCX_OSTIAL"].done
      },
      attrs: {
        slot: "hotspot-15",
        "data-name": "LCX_OSTIAL",
        "data-position":
          "0.3194179164698847m -0.010706087587260715m 0.02921884617190773m",
        "data-normal":
          "0.6716753567516066m -0.05386152413723659m -0.7388850731678209m",
        "data-visibility-attribute": "visible",
        "data-label": "LCX OSTIAL"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["LCX_OSTIAL"])
        }
      },
      slot: "hotspot-15"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done:
          _vm.pointsForm["LCX_MID_PART"] && _vm.pointsForm["LCX_MID_PART"].done
      },
      attrs: {
        slot: "hotspot-16",
        "data-name": "LCX_MID_PART",
        "data-position":
          "0.23382446102681775m -0.144046266474874m -0.009330213045604274m",
        "data-normal":
          "0.7661681275809329m -0.2192472551131038m -0.6040836377559793m",
        "data-visibility-attribute": "visible",
        "data-label": "LCX MID PART"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["LCX_MID_PART"])
        }
      },
      slot: "hotspot-16"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done: _vm.pointsForm["OM2_OSTIAL"] && _vm.pointsForm["OM2_OSTIAL"].done
      },
      attrs: {
        slot: "hotspot-17",
        "data-name": "OM2_OSTIAL",
        "data-position":
          "0.3406990808494615m -0.24682424944182668m 0.0565424565634135m",
        "data-normal":
          "0.7556229357725606m -0.32637154648381944m -0.5679045629154753m",
        "data-visibility-attribute": "visible",
        "data-label": "OM2 OSTIAL"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["OM2_OSTIAL"])
        }
      },
      slot: "hotspot-17"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done:
          _vm.pointsForm["OM2_PROXIMAL"] && _vm.pointsForm["OM2_PROXIMAL"].done
      },
      attrs: {
        slot: "hotspot-18",
        "data-name": "OM2_PROXIMAL",
        "data-position":
          "0.374728003292535m -0.29104066532055456m 0.10670563469491268m",
        "data-normal":
          "0.4093695393770095m -0.7420909774850769m -0.530770723915231m",
        "data-visibility-attribute": "visible",
        "data-label": "OM2 PROXIMAL"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["OM2_PROXIMAL"])
        }
      },
      slot: "hotspot-18"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done:
          _vm.pointsForm["OM2_MID_PART"] && _vm.pointsForm["OM2_MID_PART"].done
      },
      attrs: {
        slot: "hotspot-19",
        "data-name": "OM2_MID_PART",
        "data-position":
          "0.45089731943637057m -0.2953048843268309m 0.237842818263425m",
        "data-normal":
          "0.7877687068924033m -0.5579434843797414m -0.2609971890255984m",
        "data-visibility-attribute": "visible",
        "data-label": "OM2 MID PART"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["OM2_MID_PART"])
        }
      },
      slot: "hotspot-19"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done: _vm.pointsForm["OM1_OSTIAL"] && _vm.pointsForm["OM1_OSTIAL"].done
      },
      attrs: {
        slot: "hotspot-20",
        "data-name": "OM1_OSTIAL",
        "data-position":
          "0.3316397593033336m -0.05718886925269001m 0.030126200524684954m",
        "data-normal":
          "0.3720353039690471m 0.17107325749066868m -0.9123177479212987m",
        "data-visibility-attribute": "visible",
        "data-label": "OM1 OSTIAL"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["OM1_OSTIAL"])
        }
      },
      slot: "hotspot-20"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done:
          _vm.pointsForm["OM1_PROXIMAL"] && _vm.pointsForm["OM1_PROXIMAL"].done
      },
      attrs: {
        slot: "hotspot-21",
        "data-name": "OM1_PROXIMAL",
        "data-position":
          "0.41155826368160897m -0.10915732711682946m 0.0783351704184318m",
        "data-normal":
          "0.7224955373944705m -0.009330049498480803m -0.6913126272689016m",
        "data-visibility-attribute": "visible",
        "data-label": "OM1 PROXIMAL"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["OM1_PROXIMAL"])
        }
      },
      slot: "hotspot-21"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done:
          _vm.pointsForm["OM1_MID_PART"] && _vm.pointsForm["OM1_MID_PART"].done
      },
      attrs: {
        slot: "hotspot-22",
        "data-name": "OM1_MID_PART",
        "data-position":
          "0.4690607991927551m -0.16783226877006202m 0.19041940052629305m",
        "data-normal":
          "0.9588698754217713m -0.022633339168911113m -0.2829422095882865m",
        "data-visibility-attribute": "visible",
        "data-label": "OM1 MID PART"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["OM1_MID_PART"])
        }
      },
      slot: "hotspot-22"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done: _vm.pointsForm["OM1_DISTAL"] && _vm.pointsForm["OM1_DISTAL"].done
      },
      attrs: {
        slot: "hotspot-23",
        "data-name": "OM1_DISTAL",
        "data-position":
          "0.4849582870988952m -0.22344747939208476m 0.2941774067320132m",
        "data-normal":
          "0.9999659911067593m -0.008129378342525416m -0.0013891859633047637m",
        "data-visibility-attribute": "visible",
        "data-label": "OM1 DISTAL"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["OM1_DISTAL"])
        }
      },
      slot: "hotspot-23"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done: _vm.pointsForm["RCA_OSTIAL"] && _vm.pointsForm["RCA_OSTIAL"].done
      },
      attrs: {
        slot: "hotspot-24",
        "data-name": "RCA_OSTIAL",
        "data-position":
          "0.04413793937909383m 0.16359165762840988m 0.23831982661424134m",
        "data-normal":
          "0.4358678916554991m 0.770190443932328m 0.465645638977875m",
        "data-visibility-attribute": "visible",
        "data-label": "RCA OSTIAL"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["RCA_OSTIAL"])
        }
      },
      slot: "hotspot-24"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done:
          _vm.pointsForm["RCA_PROXIMAL"] && _vm.pointsForm["RCA_PROXIMAL"].done
      },
      attrs: {
        slot: "hotspot-25",
        "data-name": "RCA_PROXIMAL",
        "data-position":
          "-0.04976129800842244m 0.1411358322756855m 0.2844561782385679m",
        "data-normal":
          "-0.42399947374886965m 0.8313810838802999m 0.35920737691018995m",
        "data-visibility-attribute": "visible",
        "data-label": "RCA PROXIMAL"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["RCA_PROXIMAL"])
        }
      },
      slot: "hotspot-25"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done:
          _vm.pointsForm["RCA_MID_PART"] && _vm.pointsForm["RCA_MID_PART"].done
      },
      attrs: {
        slot: "hotspot-26",
        "data-name": "RCA_MID_PART",
        "data-position":
          "-0.1547995199819202m 0.0020512232162371302m 0.3504933725283198m",
        "data-normal":
          "-0.8110064411333926m 0.41888555621494666m 0.40841577250963707m",
        "data-visibility-attribute": "visible",
        "data-label": "RCA MID PART"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["RCA_MID_PART"])
        }
      },
      slot: "hotspot-26"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done: _vm.pointsForm["RCA_DISTAL"] && _vm.pointsForm["RCA_DISTAL"].done
      },
      attrs: {
        slot: "hotspot-27",
        "data-name": "RCA_DISTAL",
        "data-position":
          "-0.15536984347856264m -0.28736227920451657m 0.3082246519786328m",
        "data-normal":
          "-0.7638059220715093m -0.49536925044485086m 0.4137750827710608m",
        "data-visibility-attribute": "visible",
        "data-label": "RCA DISTAL"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["RCA_DISTAL"])
        }
      },
      slot: "hotspot-27"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done: _vm.pointsForm["PLV_OSTIAL"] && _vm.pointsForm["PLV_OSTIAL"].done
      },
      attrs: {
        slot: "hotspot-29",
        "data-name": "PLV_OSTIAL",
        "data-position":
          "0.011715229804953708m -0.40700728407913955m 0.20806619070206692m",
        "data-normal":
          "-0.5733246830735588m -0.7424585513079112m -0.34648824997157035m",
        "data-visibility-attribute": "visible",
        "data-label": "PLV OSTIAL"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["PLV_OSTIAL"])
        }
      },
      slot: "hotspot-29"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done:
          _vm.pointsForm["PLV_PROXIMAL"] && _vm.pointsForm["PLV_PROXIMAL"].done
      },
      attrs: {
        slot: "hotspot-30",
        "data-name": "PLV_PROXIMAL",
        "data-position":
          "0.0152815623403727m -0.42690212789326887m 0.27791128067005716m",
        "data-normal":
          "-0.6887216732454231m -0.7078177601755619m -0.15702380450771028m",
        "data-visibility-attribute": "visible",
        "data-label": "PLV PROXIMAL"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["PLV_PROXIMAL"])
        }
      },
      slot: "hotspot-30"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done:
          _vm.pointsForm["PLV_MID_PART"] && _vm.pointsForm["PLV_MID_PART"].done
      },
      attrs: {
        slot: "hotspot-31",
        "data-name": "PLV_MID_PART",
        "data-position":
          "0.08211476675911866m -0.4564478007373898m 0.3943582848364673m",
        "data-normal":
          "-0.20813872063532726m -0.9777904698087028m -0.024577838057191933m",
        "data-visibility-attribute": "visible",
        "data-label": "PLV MID PART"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["PLV_MID_PART"])
        }
      },
      slot: "hotspot-31"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done: _vm.pointsForm["PLV_DISTAL"] && _vm.pointsForm["PLV_DISTAL"].done
      },
      attrs: {
        slot: "hotspot-32",
        "data-name": "PLV_DISTAL",
        "data-position":
          "0.15637260972949515m -0.4629884751581601m 0.5061967996724931m",
        "data-normal":
          "-0.09977972425612237m -0.9934207462391016m 0.05620700640595281m",
        "data-visibility-attribute": "visible",
        "data-label": "PLV DISTAL"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["PLV_DISTAL"])
        }
      },
      slot: "hotspot-32"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done: _vm.pointsForm["PDA_OSTIAL"] && _vm.pointsForm["PDA_OSTIAL"].done
      },
      attrs: {
        slot: "hotspot-33",
        "data-name": "PDA_OSTIAL",
        "data-position":
          "0.11701451443713498m -0.35809466562691883m 0.07396544514151937m",
        "data-normal":
          "-0.18673750398972372m -0.9478242027751882m -0.25837644094860335m",
        "data-visibility-attribute": "visible",
        "data-label": "PDA OSTIAL"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["PDA_OSTIAL"])
        }
      },
      slot: "hotspot-33"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done:
          _vm.pointsForm["PDA_PROXIMAL"] && _vm.pointsForm["PDA_PROXIMAL"].done
      },
      attrs: {
        slot: "hotspot-34",
        "data-name": "PDA_PROXIMAL",
        "data-position":
          "0.16982531761687894m -0.42570547718014284m 0.13146993636598497m",
        "data-normal":
          "0.009913007511742306m -0.7979259672167119m -0.602673944287744m",
        "data-visibility-attribute": "visible",
        "data-label": "PDA PROXIMAL"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["PDA_PROXIMAL"])
        }
      },
      slot: "hotspot-34"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: {
        done:
          _vm.pointsForm["PDA_MID_PART"] && _vm.pointsForm["PDA_MID_PART"].done
      },
      attrs: {
        slot: "hotspot-35",
        "data-name": "PDA_MID_PART",
        "data-position":
          "0.17061707853687963m -0.4703796656771768m 0.2645840730153348m",
        "data-normal":
          "-0.3033565306246624m -0.9522105933667576m 0.035634270127165496m",
        "data-visibility-attribute": "visible",
        "data-label": "PDA MID PART"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["PDA_MID_PART"])
        }
      },
      slot: "hotspot-35"
    }),
    _vm._v(" "),
    _c("button", {
      staticClass: "Hotspot",
      class: { done: _vm.pointsForm["PD"] && _vm.pointsForm["PD"].done },
      attrs: {
        slot: "hotspot-36",
        "data-name": "PD",
        "data-position":
          "0.28492069905844686m -0.4926617051703226m 0.36777019681317574m",
        "data-normal":
          "-0.09328455985256594m -0.981477449206097m 0.16733202799525984m",
        "data-visibility-attribute": "visible",
        "data-label": "PD"
      },
      on: {
        click: function() {
          return _vm.$emit("pointClicked", _vm.points["PD"])
        }
      },
      slot: "hotspot-36"
    })
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);